package com.shortlist.pages.candidate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestData;
import com.shortlist.automationtest.utility.TestReport;


public class ChatbotPage {

	WebDriver driver = null;

	@FindBy(how = How.CSS, using = "div.no-of-jobs.ng-star-inserted span")
	private WebElement totalJobElement;

	@FindBy(how = How.XPATH, using = "//span[text()=\"Let's begin!\"]")
	private WebElement letsBeginButton;

	@FindBy(how = How.XPATH, using = "//span[text()=\"Complete chat\"]")
	private WebElement completechatButton;

	public ChatbotPage() // Constructor to initialize Web elements using Page factory
	{
		driver = SeleniumCommon.getDriverInstance();
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}

	public void startChatbot() {
		
		TestReport.startTest("Verify chatbot"); 
		
		Log.getLogger().info("Chatbot started ...");
		String jobId=TestConfiguration.getPropertyValue("chatbot.JobId");
		Log.getLogger().info("Chatbot Job ID: "+ jobId);
		
			//jobId = "1422";
			//driver.navigate().to("https://qa.shortlist.net/webportal/#/job/1420");
	
		SeleniumCommon.waitForPageLoad();
		SeleniumCommon.waitForSecond(10);
		
		String pageSource=driver.getPageSource();
		if (pageSource.contains("we want to know you better. We'll ask you a few questions to learn about you and your work") || pageSource.contains("Hi, We'd love to learn more. Let's finish the conversation")) 
		{
			Log.getLogger().info("Chatbot welcome page found");
			TestReport.testPassWithScreenshot("Chatbot welcome page found");
		} else {
			Log.getLogger().info("Chatbot welcome page not found");
			isPageLoaded();
			//Assert.fail("Chatbot welcome page not found");
		}
		
		if (driver.getPageSource().contains("Let's begin")) {
			Log.getLogger().info("Clicking on lets begin button");
		} else if (driver.getPageSource().contains("Complete chat")) {
			Log.getLogger().info("Clicking on Complete chat button");
		}
		
		By startChatButtonLocator=By.xpath("//button[@class=\"mat-raised-button\"]");
		Boolean isProceedToChatBot=SeleniumCommon.clickOnElement(startChatButtonLocator);
		if(!isProceedToChatBot)
		{
			Log.getLogger().info("Lets begin or complete chat button not clicked");
			Boolean isLetsBeginButtonEnabled=driver.findElement(startChatButtonLocator).isEnabled();
			if(!isLetsBeginButtonEnabled)
			{
				Log.getLogger().info("isLetsBeginButtonEnabled: "+ isLetsBeginButtonEnabled);
				Log.getLogger().info("Lets begin button is disabled- skip test");
				Assert.fail("Lets begin button is disabled");
			}
		}else {
			Log.getLogger().info("Clicked on lets begin or complete chat bot button");
			
		}
		SeleniumCommon.waitForPageLoad();
		SeleniumCommon.waitForSecond(5);
		String websiteUrl=TestConfiguration.getWebsiteUrl();
		String expectedURL=websiteUrl+"webportal/#/job/"+jobId+"/chatroom";
		SeleniumCommon.waitForURL(expectedURL);
		if(driver.getCurrentUrl().contains(expectedURL))  // In case new user it should match URL
		{
			Log.getLogger().info("Actual URL   : "+ driver.getCurrentUrl());
			Log.getLogger().info("Expected URL : "+ expectedURL);
			Log.getLogger().info("User is redirected to chatbot page");
		}else {
			Log.getLogger().info("Actual URL   : "+ driver.getCurrentUrl());
			Log.getLogger().info("Page Title   : "+ driver.getTitle());
			Log.getLogger().info("Expected URL : "+ expectedURL);
			Log.getLogger().info("User is not redirected to chatbot page");
			isPageLoaded();
			Assert.fail("User is not redirected to chatbot page after click on lets begin button");
		
		}
		
		

		By welComeTitleElement = By.xpath("//app-chatbot-question[@class=\"ng-star-inserted\"]");
		Boolean isChatbotWelcomeTitleExist = SeleniumCommon.isElementExist(welComeTitleElement); //Chatbot welcome title
		Log.getLogger().info("isTitleExit: " + isChatbotWelcomeTitleExist);
		SeleniumCommon.waitForSecond(5); // Wait for first question load
		String previousQuestion = "";
		int count = 0, questionCounter=0;
		
		if(isChatbotWelcomeTitleExist)
		{
			TestReport.testPassWithScreenshot("chatbot loaded");
			
		}
		

		while (isChatbotWelcomeTitleExist) {

			By nextQuestionDescription = By.xpath("//app-chatbot-question[last()]/div[1]/div");
			Boolean isQuestionExit = SeleniumCommon.isElementExist(nextQuestionDescription);
			if (isQuestionExit) {
				String currentQuestionText = driver.findElement(nextQuestionDescription).getText();
				Log.getLogger().info("questionText: " + currentQuestionText);

				if (count == 0) {
					previousQuestion = currentQuestionText;
					questionCounter++;
					Log.getLogger().info("questionCounter: "+ questionCounter);
				}

				if (previousQuestion.equalsIgnoreCase(currentQuestionText)) {
					count++;
				} else {
					count = 0;
				}

				if (count == 5) {
					Log.getLogger().info("Exit from chat, something went wrong ......");
					if (previousQuestion.equalsIgnoreCase(currentQuestionText)) {
						By questionLoader = By.xpath(
								"//div[@class=\"chatbot-footer-mobile ng-star-inserted\"]/div/div/div[@class=\"loader\"]");
						Boolean isNextQuestionNotLoading = SeleniumCommon.isElementExist(questionLoader);
						Log.getLogger().info("isNextQuestionNotLoading ......" + isNextQuestionNotLoading);
						Log.getLogger().info("Next question not loaded ......even after waiting 1 minute");
						SeleniumCommon.takeScreenshot();
						checkAnyWarningMessage();
						isPageLoaded();
						Assert.fail("Next chatbot question not loaded even after waiting 1 minute");

					}

					break;
				}

			}

			InputType inputPatten= getInputPattern();
			Log.getLogger().info("Pattern Found: " + inputPatten);
			sendInputToChatBot(inputPatten);
			SeleniumCommon.waitForSecond(3);

			// By checkResponse=
			// By.xpath("//mat-sidenav-content[1]/section[1]/app-chatbot-preview[1]/div[1]/div[2]/div[1]/div[1]/app-chatbot-answer[4]/div[1]");
			// This xpath find chat bot response show or not - 4th response ->
			// app-chatbot-answer[4]

			Boolean isResponseSubmit = driver.getPageSource().contains("submit-application ng-star-inserted");
			Log.getLogger().info("isResponseSubmitButtonEnabled: " + isResponseSubmit);
			
			if (inputPatten==InputType.SUBMITRESPONSE && isResponseSubmit) {
				
				Boolean isContinue = SeleniumCommon
						.isElementExist(By.xpath("//p[@class=\"progress-value\"]/span[text()=\"Completed\"]"));
				Boolean isSubmitResponse = SeleniumCommon
						.isElementExist(By.xpath("//div[@class=\"submit-application ng-star-inserted\"]/button"));
				Log.getLogger().info("isContinue: " + isContinue);
				Log.getLogger().info("isSubmitResponse: " + isSubmitResponse);
				
				if (isSubmitResponse) {
					
					TestReport.testPassWithScreenshot("Submitting chatbot response");
					
					driver.findElement(By.xpath("//div[@class=\"submit-application ng-star-inserted\"]/button"))
							.click();
					Log.getLogger().info("Response Submitted....");
					SeleniumCommon.waitForSecond(6);
					SeleniumCommon.waitForPageLoad();
					
					By chatBotResultStatuTextLocator=By.xpath("//div[@class=\"job-application-intro-section\"]/p[@class=\"job-home-chat\"]");
					Boolean isChatbotResultDisplayed= SeleniumCommon.isElementExist(chatBotResultStatuTextLocator);
					if(isChatbotResultDisplayed)
					{
						String chatbotStatusTitle="";
					    Boolean isStatusExist=SeleniumCommon.isElementExist(chatBotResultStatuTextLocator);
						if (isStatusExist) {
							chatbotStatusTitle = driver.findElement(chatBotResultStatuTextLocator).getText();
							Log.getLogger().info("ChatBot Status: " + chatbotStatusTitle);
						}
					}
					
					if (driver.getPageSource().contains("Thank you for applying")) {
						Log.getLogger().info("**** You are not eligibility for assignment");
						TestConfiguration.putValue("Charlie.assessment.execute", "skip");
						TestReport.testPassWithScreenshot("You are not eligibility for assignment");
						/*
						 * By goToJobPageButton =
						 * By.xpath("//div[@class=\"job-home-appy-button\"]/button");
						 * SeleniumCommon.isElementExist(goToJobPageButton);
						 * driver.findElement(goToJobPageButton).click();
						 */

					} else if (driver.getPageSource().contains("Assessment")) {
						Log.getLogger().info("**** You are now eligibility for assignment");
						TestReport.testPassWithScreenshot("You are now eligibility for assignment");
						/*
						 * By letsGoButton = By.xpath("//span[text()=\"Let's go!\"]");
						 * SeleniumCommon.isElementExist(letsGoButton);
						 * driver.findElement(letsGoButton).click();
						 */

						// driver.navigate().to("https://www.shortlist.net/webportal/#/dashboard/all-jobs");
						// Log.getLogger().info("Redirected to jobs page:");
					}else if(driver.getPageSource().contains("You're done! Thanks for taking time to show your strengths. We'll be in touch as your application gets reviewed")) 
					{
						Log.getLogger().info("In Review Process"); // there is no any assessment configured for this job
						TestReport.testPassWithScreenshot("In Review Process");
					}else {
						
						Log.getLogger().info("Chatbot submmited- not found any status after submitting chatbot");
						
					}
					
					
				}
			

				
					break; //chatbot submitted so come out of loop
			
			}
		}

		if (!isChatbotWelcomeTitleExist) {
			Log.getLogger().info("---- Chat question not loaded, test fail ----");
			checkAnyWarningMessage();
			isPageLoaded();
			Assert.fail("Chatbot welcome page not loaded");

		}

	}

	
	
	
	public InputType getInputPattern() {

		String inputPattern = "SubmitResponse ";
		String pageSource=driver.getPageSource();
		InputType input=InputType.SUBMITRESPONSE;

		if (pageSource.contains("name=\"chatMessage\" required=\"\" type=\"text\"")) {
			inputPattern = inputPattern + " TEXT";
			input=InputType.TEXT;
		} 
		
		Boolean isOnlyNumber = driver.getPageSource().contains(
				"name=\"chatMessage\" onkeydown=\"javascript: return event.keyCode == 69 ? false : true\" required=\"\" type=\"number\"");
		
		if (pageSource.contains("name=\"chatMessage\" required=\"\" type=\"number\"") || isOnlyNumber) {
			inputPattern =inputPattern + " NUMBER";
			input=InputType.NUMBER;
		} 

		if (pageSource.contains("class=\"options-message ng-star-inserted")) {
			inputPattern = inputPattern +" OPTION";
			input=InputType.OPTION;
		} 
		

		if (pageSource.contains("mat-input-element mat-form-field-autofill-control") || pageSource.contains("class=\"autoSelectSendButton\"")) {
			inputPattern = inputPattern +" DROPDOWN";
			input=InputType.DROPDOWN;
		} 

		if (pageSource.contains("name=\"salaryAmount\"")) {
			inputPattern = inputPattern +" SALARY";
			input=InputType.SALARY;
		}

		if (pageSource.contains("name=\"countryCode\"")) {
			inputPattern = inputPattern +" MOBILE";
			input=InputType.MOBILE;
		} 

		if (pageSource.contains("class=\"date-picker-icon mat-datepicker-toggle")) {
			inputPattern = inputPattern +" DATEPICKER";
			input=InputType.DATEPICKER;
		} 
		
		
		if (input==InputType.DATEPICKER && input==InputType.TEXT) {
			inputPattern = inputPattern +" DATEPICKER";
			input=InputType.DATEPICKER;
		}

		if (pageSource.contains("name=\"grade\"") || pageSource.contains("class=\"chatBotTextForm chatbotGradeForm")) {
			inputPattern =inputPattern + " GRADE";
			input=InputType.GRADE;
		}
		
		if(pageSource.contains("app-file-upload") || pageSource.contains("class=\"open-document-viewer ng-star-inserted\""))
		{
			inputPattern = inputPattern +" FILEUPLOAD";
			input=InputType.FILEUPLOAD;
		}

		if (pageSource.contains("class=\"skip-btn mat-button mat-primary ng-star-inserted")	|| pageSource.contains("class=\"skip-btn mat-button mat-primary\""))
		{
			//inside skip

			if (input==InputType.DROPDOWN) //inside skip if dropdown found 
			{
				inputPattern =inputPattern + " DROPDOWN_SKIP";
				input=InputType.DROPDOWN_SKIP;
			} 
			else if(input==InputType.FILEUPLOAD)  //inside skip if file upload found 
			{
				inputPattern = inputPattern +" FILEUPLOAD_SKIP";
				input=InputType.FILEUPLOAD_SKIP;
			}
			else {
				
				inputPattern = inputPattern +" SKIP";
				input=InputType.SKIP;
			}
		} 
		
		Log.getLogger().info("---------------------------------------------------");
		Log.getLogger().info("Input Pattern found: "+ inputPattern);
		Log.getLogger().info("Data Type: "+ input);

		
		 return input;
	}
	
	
	public String getQuestion() {
		
		By nextQuestionDescription = By.xpath("//app-chatbot-question[last()]/div[1]/div");
		String currentQuestionText = "";
		currentQuestionText = driver.findElement(nextQuestionDescription).getText();
		Log.getLogger().info("Current Question: "+ currentQuestionText);
		return currentQuestionText;
	}
	
	

	public void sendInputToChatBot(InputType input) {

		
		By sendButtonLocator = By.xpath("//button[not(@disabled)]//mat-icon[text()=\"send\"]");
		By senDisabledButtonLocator = By.xpath("//button[@disabled]//mat-icon[text()=\"send\"]");
		By inputTextBoxLocator=By.xpath("//input[@name=\"chatMessage\"]");

		if (input==InputType.DROPDOWN || input==InputType.DROPDOWN_SKIP) {

			Log.getLogger().info("-->DROPDOWN");
			
			SeleniumCommon.isElementExist(senDisabledButtonLocator);
			driver.findElement(senDisabledButtonLocator).click();

			By dropDownOptionListLocator = By.xpath("//div[@role=\"listbox\"]/mat-option");
			Boolean isDropDownOptionListExist = SeleniumCommon.isElementExist(dropDownOptionListLocator,5);

			if (!isDropDownOptionListExist) {
               Log.getLogger().info("Enter input for API call");
				String testData = TestData.getInputTestData(getQuestion(), "API_CALL");
				if (!testData.isBlank()) {
					driver.findElement(By.xpath("//input")).clear();
					driver.findElement(By.xpath("//input")).sendKeys(testData);
				} else {
					driver.findElement(By.xpath("//input")).clear();
					driver.findElement(By.xpath("//input")).sendKeys("a");
				}

			}
			
			isDropDownOptionListExist = SeleniumCommon.isElementExist(dropDownOptionListLocator,5);
			
			if (!isDropDownOptionListExist)
			{
				char[] charList = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','O','P','Q','R','S','T' };
				for (char ch : charList) {
					String inputStr=String.valueOf(ch);
					driver.findElement(By.xpath("//input")).clear();
					driver.findElement(By.xpath("//input")).sendKeys(inputStr);
					isDropDownOptionListExist = SeleniumCommon.isElementExist(dropDownOptionListLocator,10);
					if(isDropDownOptionListExist)
					{
						Log.getLogger().info("Option list found");
						break;
					}
						
				}
			}
			
			
			//SeleniumCommon.waitForSecond(1);
			List<WebElement> dropdownOptionListElement = driver.findElements(dropDownOptionListLocator);
			int noOfOptions = dropdownOptionListElement.size();
			Log.getLogger().info("Total dropdown options:" + noOfOptions);
			if (noOfOptions != 0) {
				WebElement optionElement = null;
				if (noOfOptions == 1) {
					optionElement = dropdownOptionListElement.get(0);// index start with zero
				} else {
					noOfOptions = noOfOptions - 1;
					int randomOptionChoice = 1;
					if (noOfOptions >= 5) {
						randomOptionChoice = GenerateTestData.getRandomNumberFromRange(1, 5);
					}
					optionElement = dropdownOptionListElement.get(randomOptionChoice); // select random choice
				}
				
				Log.getLogger().info("Dropdown option selecting: "+ optionElement.getText());
				//SeleniumCommon.waitForSecond(5);
				//optionElement.click();
				Actions builder = new Actions(driver);
				builder.moveToElement(optionElement).click(optionElement);
				SeleniumCommon.waitForSecond(2);
				builder.perform();
				driver.findElement(sendButtonLocator).click();
				Log.getLogger().info("Option selected from dropdown or auto populate selected");
			} else {
				Log.getLogger().info("Somethings went wrong");
			}

		} 
		else if (input==InputType.TEXT)
		{
			Log.getLogger().info("-->TEXT");
			SeleniumCommon.waitForSecond(2);
			SeleniumCommon.isElementExist(inputTextBoxLocator);
			driver.findElement(inputTextBoxLocator).clear();
			
			String testData = TestData.getInputTestData(getQuestion(), "INPUT_TEXT");
			if (!testData.isBlank()) {
				driver.findElement(inputTextBoxLocator).sendKeys(testData);
			} else {
				driver.findElement(inputTextBoxLocator).sendKeys("Lorem Ipsum is not simply random text");
			}

			//SeleniumCommon.isElementExist(By.xpath("//input[@name=\"chatMessage\"]/following::button[not(@disabled)]/span"));
			//driver.findElement(By.xpath("//input[@name=\"chatMessage\"]/following::button[not(@disabled)]/span")).click();
			SeleniumCommon.isElementExist(sendButtonLocator);
			driver.findElement(sendButtonLocator).click();

			Log.getLogger().info("Text Entered");
		} 
		else if (input==InputType.NUMBER)
		{
			
			Log.getLogger().info("-->NUMBER");
			SeleniumCommon.waitForSecond(2);
			SeleniumCommon.isElementExist(inputTextBoxLocator);
			driver.findElement(inputTextBoxLocator).clear();
			
			String testData = TestData.getInputTestData(getQuestion(), "INPUT_TEXT");
			if (!testData.isBlank()) {
				driver.findElement(inputTextBoxLocator).sendKeys(testData);
			}else
			{
				driver.findElement(inputTextBoxLocator).sendKeys("12");
			}

			SeleniumCommon.isElementExist(sendButtonLocator);
			driver.findElement(sendButtonLocator).click();

			SeleniumCommon.waitForSecond(2);
			if (driver.getPageSource().contains("class=\"warning-message-text"))
			{
				Log.getLogger().info("**** Warning occured due to invalid input ");
				String expectedAnwser = getAnswerFromValidationMessage();

				if (expectedAnwser != null) {
					Log.getLogger().info("Expected Answer :" + expectedAnwser);
					SeleniumCommon.isElementExist(inputTextBoxLocator);
					driver.findElement(inputTextBoxLocator).clear();
					driver.findElement(inputTextBoxLocator).sendKeys(expectedAnwser);
					SeleniumCommon.isElementExist(sendButtonLocator);
					driver.findElement(sendButtonLocator).click();
				}
			}

			Log.getLogger().info("Number Entered");
		} 
		else if (input==InputType.OPTION)
		{
			Log.getLogger().info("-->OPTION");
			
			int totalOptions = driver.findElements(By.xpath("//app-chatbot-question[last()]/div[@class=\"options-message ng-star-inserted\"]")).size();
			Log.getLogger().info("total Options: " + totalOptions);
			int randomChoiceNumber = GenerateTestData.getRandomChoiceNumber(totalOptions);
			
			By optionElement=By.xpath("//app-chatbot-question[last()]/div[@class=\"options-message ng-star-inserted\"]["+randomChoiceNumber+"]/span");
			String OptionStr=driver.findElement(optionElement).getText();
			driver.findElement(optionElement).click();
			Log.getLogger().info("Option Selected: "+ OptionStr);
		} 
		else if (input==InputType.SALARY)
		{
			Log.getLogger().info("-->SALARY");
			SeleniumCommon.waitForSecond(2);
			By salaryAmountLocator = By.xpath("//input[@name=\"salaryAmount\"]");
			SeleniumCommon.isElementExist(salaryAmountLocator);
			
			String testData = TestData.getInputTestData(getQuestion(), "INPUT_TEXT");
			if (!testData.isBlank()) {
				driver.findElement(salaryAmountLocator).sendKeys(testData);
			} else {
				driver.findElement(salaryAmountLocator).sendKeys("860000");
			}
			
			Log.getLogger().info("Salary entered");
			SeleniumCommon.waitForSecond(10);

			WebElement sendButtonOnMouseClick = driver.findElement(sendButtonLocator);

			Actions builder = new Actions(driver);
			builder.moveToElement(sendButtonOnMouseClick).click(sendButtonOnMouseClick);
			builder.perform();

		} 
		else if (input==InputType.MOBILE)
		{
			Log.getLogger().info("-->MOBILE");
			SeleniumCommon.waitForSecond(2);
			SeleniumCommon.isElementExist(inputTextBoxLocator);
			driver.findElement(inputTextBoxLocator).sendKeys("");
			String mobileNumber=GenerateTestData.getMobileNumber();
			driver.findElement(inputTextBoxLocator).sendKeys(mobileNumber);

			SeleniumCommon.isElementExist(sendButtonLocator);
			driver.findElement(sendButtonLocator).click();

			Log.getLogger().info("Mobile Number Entered");
		}
		else if (input==InputType.DATEPICKER) 
		{
			
			Log.getLogger().info("-->DATEPICKER");
			SeleniumCommon.waitForSecond(2);
			
			String date = GenerateTestData.getDate();
			datePickerDateSelection(date);
			By dateInputBox = By.xpath("//input[1]");
			boolean isDateInputExit = SeleniumCommon.isElementExist(dateInputBox,5);
			if (isDateInputExit) {
				String dateValue = driver.findElement(dateInputBox).getAttribute("value");
				Log.getLogger().info("Selected Date: " + dateValue);
			} else {
				Log.getLogger().info(" Date input element not found");
			}
			
			By sendIconLocator=By.xpath("//mat-icon[text()='send']");
			SeleniumCommon.clickOnElement(sendIconLocator);

			Log.getLogger().info("datepicker selected");

		} 
		else if (input==InputType.GRADE) {
			
			Log.getLogger().info("-->GRADE");
			SeleniumCommon.waitForSecond(2);
			SeleniumCommon.isElementExist(inputTextBoxLocator);
			driver.findElement(inputTextBoxLocator).clear();
			driver.findElement(inputTextBoxLocator).sendKeys("3");
			SeleniumCommon.isElementExist(sendButtonLocator);
			driver.findElement(sendButtonLocator).click();
			

		}
		else if (input==InputType.FILEUPLOAD || input==InputType.FILEUPLOAD_SKIP)
		{
			Log.getLogger().info("-->FILEUPLOAD");
			By attachementIcon = By.xpath(
					"//button[@class=\"mat-icon-button mat-primary ng-star-inserted\"]/span/mat-icon[text()=\"attachment\"]");
			Boolean isAttachmentIconAvailable = SeleniumCommon.isElementExist(attachementIcon);
			if (isAttachmentIconAvailable) {
				driver.findElement(attachementIcon).click();

				By uploadFileElement = By.xpath("//input[@type=\"file\"]");
				SeleniumCommon.isElementExist(uploadFileElement);
				
				String testData = TestData.getInputTestData(getQuestion(), "INPUT_TEXT");
				if (!testData.isBlank())
				{
					driver.findElement(uploadFileElement).sendKeys(testData);
				}
				
				Log.getLogger().info("File uploaded ...");
			}
			
		}
		else if (input==InputType.SKIP) {

			Log.getLogger().info("-->SKIP");
			
			String testData = TestData.getInputTestData(getQuestion(), "INPUT_TEXT");
			if (!testData.isBlank()) {
				SeleniumCommon.sendInput(inputTextBoxLocator, testData);
				SeleniumCommon.clickOnElement(sendButtonLocator);
			} else {

				Log.getLogger().info("checking skip button");
				By skipIcon1 = By.xpath("//span[text()=\"SKIP\"]");
				Boolean skipIconElement = SeleniumCommon.isElementExist(skipIcon1);
				Boolean isClicked = false;
				if (skipIconElement) {
					isClicked = SeleniumCommon.clickOnElement(skipIcon1);
				} else if (!isClicked) {
					By skipIcon2 = By.xpath("//button[@class=\"skip-btn mat-button mat-primary\"]");
					SeleniumCommon.clickOnElement(skipIcon2);
					Log.getLogger().info("clicked on skip button");
				}
			}
		}

	}
	
	
	

	public String getAnswerFromValidationMessage() {
		By message_ItemLocator = By.xpath(
				"(//app-chatbot-question)[last()]/div[@class=\"message ng-star-inserted\"][last()]/div[@class=\"message-item\"]");
		SeleniumCommon.isElementExist(message_ItemLocator);
		String message_Item = driver.findElement(message_ItemLocator).getText();
		String answer = null;
		if (message_Item.contains("like")) {
			String[] arrOfStr = message_Item.split("like");
			try {

				String[] arrOfStr2 = arrOfStr[1].split("or");

				answer = arrOfStr2[1];

			} catch (Exception e) {
			}
		}
		return answer;

	}
	
	
	public String getValidationMessage() {
		
		String message="";
		
		if(driver.getPageSource().contains("class=\"error-message ng-star-inserted\""))
		{
			By validationMessageTextLocator=By.xpath("//div[@class=\"error-message ng-star-inserted\"]/div[2]");
			Boolean isValidationMessageExist=SeleniumCommon.isElementExist(validationMessageTextLocator, 10);
			if(isValidationMessageExist)
			{
				message=driver.findElement(validationMessageTextLocator).getText();
				Log.getLogger().info("Validation message found :"+ message);
			}
			
		}else {
			Log.getLogger().info("-- Validation message not found");
			
		}
		
		return message;
	}
	
	
	public void isPageLoaded() {
		
		if(driver.getPageSource().contains("mat-spinner mat-progress-spinner mat-primary mat-progress-spinner-indeterminate-animation"))
		{
			By loaderLocator=By.xpath("//mat-spinner[@role=\"progressbar\"]");
			Boolean isLoaderShowingOnPage=SeleniumCommon.isElementExist(loaderLocator);
			if(isLoaderShowingOnPage) {
				Log.getLogger().info("Chatbot page not loaded, please check screenshot");
			}else {
				Log.getLogger().info("Chatbot page loaded, No page load issue");
			}
		}
	}
	
	

	public void checkAnyWarningMessage() {

		// Check any warning message appears on page

		if (driver.getPageSource()
				.contains("//simple-snack-bar[@class=\"mat-simple-snackbar ng-star-inserted\"]/span")) {

			By warmingPup = By.xpath("//simple-snack-bar[@class=\"mat-simple-snackbar ng-star-inserted\"]/span");
			Boolean isWarningPopupExit = SeleniumCommon.isElementExist(warmingPup);
			if (isWarningPopupExit) {
				String warningMessage = driver.findElement(warmingPup).getText();
				Log.getLogger().info("----> Warning Message :" + warningMessage);
				SeleniumCommon.takeScreenshot();
			}
		}else {
			
			Log.getLogger().info("Warning message not found");
		}
	}

	
	
	
	
	public enum InputType
	{
		TEXT,NUMBER,MOBILE,OPTION,DROPDOWN,DATEPICKER,SALARY,GRADE,SKIP,FILEUPLOAD,DROPDOWN_SKIP,FILEUPLOAD_SKIP,NONE,SUBMITRESPONSE
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void datePickerDateSelection(String inputDate) {

		Log.getLogger().info("---- Inside date Picker Selection --");
		if(!isValidDate(inputDate))
		{
			inputDate="02/1985";
			Log.getLogger().info("Date is not in valid, set default date "+ inputDate);
		}
		
		Calendar now = Calendar.getInstance();
	    //int currentYear=now.get(Calendar.YEAR)+5;
		int currentYear=now.get(Calendar.YEAR);
		int year_input=Integer.parseInt(inputDate.split("/")[1]);
		if(!(year_input>=1920 && year_input<=currentYear))
		{
			inputDate="02/1985";
			Log.getLogger().info("Provided is date is not in range, set default date "+ inputDate);
		}
			
		String year_ = inputDate.split("/")[1];
		int month_ = Integer.parseInt(inputDate.split("/")[0]);

		By datePickerIcon = By.xpath("//mat-datepicker-toggle[@class=\"date-picker-icon mat-datepicker-toggle\"]");
		By datePickerPreviousIcon = By.xpath("//div[@class=\"mat-calendar-controls\"]/button[2]");
		By datePickerNextIcon = By.xpath("//div[@class=\"mat-calendar-controls\"]/button[3]");
		By datePickerTable = By.xpath("//tbody[@class=\"mat-calendar-body\"]/tr[1]/td[1]");
		By dateRangeElement = By.xpath("//button[@class=\"mat-calendar-period-button mat-button\"]/span");

		Boolean datePickerPopupExit = SeleniumCommon.isElementExist(datePickerIcon);
		Boolean isExitFromDatePicker = false;

		if (datePickerPopupExit) {

			SeleniumCommon.clickOnElement(datePickerIcon);
			Boolean datePickerPreviousIconExit = SeleniumCommon.isElementExist(datePickerPreviousIcon);

			if (datePickerPreviousIconExit) {
				
				SeleniumCommon.clickOnElement(datePickerPreviousIcon);
				Boolean datePickerTableExit = SeleniumCommon.isElementExist(datePickerTable);

				while (datePickerTableExit) {
					if (isExitFromDatePicker) {
						break;
					}
					
					Boolean dateRangeExit = SeleniumCommon.isElementExist(dateRangeElement);
					if (dateRangeExit) {
						
						String dateRangeText = driver.findElement(dateRangeElement).getText();
						int previousNextNavigation = checkDateInRange(dateRangeText, year_);

						// previousNextNavigation -> Zero - In range, One-> Previous, two-> Next

						if (previousNextNavigation == 0) // in the range date found
						{

							for (int row = 1; row <= 6; row++) {
								if (isExitFromDatePicker) {
									break;
								}
								for (int column = 1; column <= 4; column++) {
									if (isExitFromDatePicker) {
										break;
									}
									By yearLocator = By.xpath(
											"//tbody[@class=\"mat-calendar-body\"]/tr[" + row + "]/td[" + column + "]");
									SeleniumCommon.isElementExist(yearLocator);
									String yearText = driver.findElement(yearLocator).getText();
									if (yearText.equals(year_)) {
										
										SeleniumCommon.clickOnElement(yearLocator);
										Log.getLogger().info("Year selected: " + yearText);

										
										int rowColumnIndex[] = getMonthRowIndex(month_);
										
										Log.getLogger().info("Selected month: Row : "+ rowColumnIndex[0] + " Column :"+ rowColumnIndex[1]);
										By monthLocator = By.xpath("//tbody[@class=\"mat-calendar-body\"]/tr["
												+ rowColumnIndex[0] + "]/td[" + rowColumnIndex[1] + "]");
										SeleniumCommon.clickOnElement(monthLocator);
										Log.getLogger().info("Month Selected");
										isExitFromDatePicker = true;
									}

								}
							}

						} else if (previousNextNavigation == 1) {
							Log.getLogger().info("previousNextNavigation 1");
							SeleniumCommon.clickOnElement(datePickerPreviousIcon);
							//SeleniumCommon.waitForPageLoad();
							Log.getLogger().info("previousNextNavigation 1- end");
						} else if (previousNextNavigation == 2) {
							Log.getLogger().info("previousNextNavigation 2");
							SeleniumCommon.clickOnElement(datePickerNextIcon);
							//SeleniumCommon.waitForPageLoad();
							Log.getLogger().info("previousNextNavigation 2- end");
							
						}

					}

				}
			}
		}
		
		Boolean isExitPopup=SeleniumCommon.isElementExist(datePickerTable);
		if(isExitPopup)
		{
			Log.getLogger().info("Date picker closing");
			//SeleniumCommon.clickOnElement(datePickerIcon);
			Log.getLogger().info("Date picker closed");
		}
		Log.getLogger().info("-- End of date picker ---");

	}

	public int checkDateInRange(String dateRange, String strYear) {

		int year = Integer.parseInt(strYear);

		String arr[] = dateRange.split(" ");
		int min = Integer.parseInt(arr[0]);
		int max = Integer.parseInt(arr[2]);

		if (year <= max && year >= min) {
			// in range
			return 0;
		} else {
			// not In range 
			if (year <= max) {
				// "Previous"
				return 1;
			} else {
				// Next
				return 2;
			}
		}
	}

	public int[] getMonthRowIndex(int month) {
		
		// Find Row index
		int rowIndex = 0;
		int columnIndex=0;
		if (month <= 4) {
			rowIndex = 1;
		} else if (month >= 5 && month <= 8) {
			rowIndex = 2;
		} else if (month >= 9 && month <= 12) {
			rowIndex = 3;
		}
		
		rowIndex = rowIndex + 1; //First showing selected year i.e count after first row
		Log.getLogger().info("Row Index: "+ rowIndex);
		
		// Find column index
		HashMap<Integer, Integer> l1 = new HashMap<Integer, Integer>();
		l1.put(1, 1);
		l1.put(2, 2);
		l1.put(3, 3);
		l1.put(4, 4);
		l1.put(5, 1);
		l1.put(6, 2);
		l1.put(7, 3);
		l1.put(8, 4);
		l1.put(9, 1);
		l1.put(10, 2);
		l1.put(11, 3);
		l1.put(12, 4);
		columnIndex=l1.get(month);
		Log.getLogger().info("Column Index: "+ columnIndex);
		
		int[] index = new int[2]; 
		index[0]=rowIndex;
		index[1]=columnIndex;
		
		
		return index;

	}

	public boolean isValidDate(String strDate) {

		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");
			//Date javaDate = dateFormat.parse(strDate);
			dateFormat.parse(strDate);
			Log.getLogger().info(strDate + " is valid date format");
			return true;
		}
		catch (ParseException e) {
			Log.getLogger().info(strDate + " is Invalid Date format");
			return true;
		}
	    
	}
	
	
	
	
	
	
	
}
