package com.shortlist.pages.employer;

public class EmployerDashboardPage {

}
