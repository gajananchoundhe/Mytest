package com.shortlist.pages.candidate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;
import org.testng.SkipException;

import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestReport;

public class JobsPage {
	
	WebDriver driver = null;
	
	public JobsPage()  // Constructor to initialize Web elements using Page factory
    {
        driver = SeleniumCommon.getDriverInstance();
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 10), this);
    }
		
	

    public void applyJob() {
    	
    	TestReport.startTest("Verify apply job", "Verify user is able to click on apply button on JD page");
    	
    	Log.getLogger().info("Apply job started ...");
    	String actualPageUrl=driver.getCurrentUrl();
    	Log.getLogger().info("Actual Page URL: "+ actualPageUrl);
    	
    	String JobIdInput=TestConfiguration.getJobId();
    	Log.getLogger().info("JobIdInput: "+ JobIdInput);
    	
         By noOfJobsCountLocator=By.cssSelector("div.no-of-jobs.ng-star-inserted span");
         Boolean isJobCountExit= SeleniumCommon.isElementExist(noOfJobsCountLocator);
         
         int jobCount=0;
 		if (isJobCountExit) {
 			String totalJobsStr = "";
 			totalJobsStr = driver.findElement(noOfJobsCountLocator).getText();
 			if (!totalJobsStr.isBlank()) {
 				jobCount=Integer.parseInt(totalJobsStr);
 				if (jobCount==0) {
 					Log.getLogger().info("Total Jobs (Zero) : " + jobCount);
 				} else {
 					Log.getLogger().info("Total Jobs: " + jobCount);
 				}
 			} else {
 				Log.getLogger().info("jobs count not found");
 			}
 		} else {
 			Log.getLogger().info("Job count element not found");
 		}
 		
 		
 		
        String websiteUrl=TestConfiguration.getWebsiteUrl();
    	
 		int applyJobDetails[]=getApplyJobByMethod(JobIdInput);
 		
		if (applyJobDetails[0] == 2) {
 			
			int jobIndexNumber=applyJobDetails[1];
			if(jobCount<=jobIndexNumber)
	 		{
				jobIndexNumber=jobCount;
	 		}
			Log.getLogger().info("Applying job by index number");	
			Log.getLogger().info("Index number: " + applyJobDetails[1]);

			By applyButtonOnJobsPageLocator = By.xpath("(//span[text()=\" APPLY \"])[" + jobIndexNumber + "]");
			Boolean isClickedOnApplyButtonOnJobsPages = SeleniumCommon.clickOnElement(applyButtonOnJobsPageLocator);

			if (isClickedOnApplyButtonOnJobsPages) {

				By jobTitleLocator=By.xpath("(//span[text()=\" APPLY \"])[" + jobIndexNumber + "]/ancestor::div[2]/div/a");
				SeleniumCommon.isElementExist(jobTitleLocator);
				String jobTitle = driver.findElement(jobTitleLocator).getAttribute("title");
				Log.getLogger().info("jobTitle: " + jobTitle);

				By jobUrlLocator=By.xpath("(//span[text()=\" APPLY \"])[" + jobIndexNumber + "]/ancestor::div[2]/div/a");
				SeleniumCommon.isElementExist(jobUrlLocator);
				String jobURL = driver.findElement(jobUrlLocator).getAttribute("href");
				
				Log.getLogger().info("Job URL: " + jobURL);
				String actualJobPageUrl=websiteUrl+"webportal/#/job-details";
				Log.getLogger().info("ActualJobPageUrl: "+ actualJobPageUrl);
			
				if (jobURL.contains(actualJobPageUrl)) {
					String jobId = jobURL.split("/")[6];
					TestConfiguration.putValue("chatbot.JobId", jobId);
					Log.getLogger().info("Job ID: " + jobId);
					SeleniumCommon.waitForSecond(5);
				
					if (driver.getCurrentUrl()
							.equalsIgnoreCase(websiteUrl+"webportal/#/job/" + jobId + "/description")) {
						Log.getLogger().info("Job description web page displayed");
						Log.getLogger().info(
								"Redirect to page after click on apply button on jobs page :" + driver.getCurrentUrl());
						
					} else {
						Log.getLogger().info("Job description web page not displayed");
						Log.getLogger().info(
								"Redirect to page after click on apply button on jobs page :" + driver.getCurrentUrl());
					}
				}
				
				clickOnApplyButtonOnJDPage();
				
			}else {
	 			Log.getLogger().info("Not clicked on job apply button on the jobs page....");
	 		}


 		} else if (applyJobDetails[0] == 1)
 		{
 		
 			Log.getLogger().info("Applying job by job Id");
 			int jobId=applyJobDetails[1];
 			Log.getLogger().info("Job ID: " + jobId);
 			TestConfiguration.putValue("chatbot.JobId", String.valueOf(jobId));
 			String URL=websiteUrl+"webportal/#/job-details/"+jobId+"";
 			Log.getLogger().info("URL: "+ URL);
 			driver.navigate().to(URL);
 			SeleniumCommon.waitForSecond(2);
 			clickOnApplyButtonOnJDPage();
 			
 		}else {
 			Log.getLogger().info("Job apply method not found, please check user jobId input");
 		}
	}
    
	
    
    

    
    public void clickOnApplyButtonOnJDPage() {
		
    	TestReport.testPassWithScreenshot("JD web page displayed");
		TestReport.testInfo(driver.getCurrentUrl());
		
    	Log.getLogger().info("Searching for apply button on JD page");
    	
		By applyButtonOnJD2PageLocator = By.xpath("//*[@class=\"apply mat-raised-button mat-primary\"]");
		Boolean isApplyButtonOnJD2PageExist = SeleniumCommon.isElementExist(applyButtonOnJD2PageLocator);
		if (isApplyButtonOnJD2PageExist) {
			Log.getLogger().info("Clicking on apply button on JD 2 page");
			Boolean isClickedOnApplyButton = SeleniumCommon.clickOnElement(applyButtonOnJD2PageLocator);
			if (!isClickedOnApplyButton) {
				Boolean isApplyButtonEnabled = driver.findElement(applyButtonOnJD2PageLocator).isEnabled();
				if (!isApplyButtonEnabled) {
					Log.getLogger().info("isApplyButtonEnabled: " + isApplyButtonEnabled);
					Log.getLogger().info("Apply button is disabled- skip test");
					throw new SkipException("Apply button is disabled - Skipping this exception");
				}
			}

		} else {

			By applyButtonOnJD1PageLocator = By.xpath("//button[@class=\"apply-btn mat-flat-button\"]");
			Boolean isApplyButtonOnJD1PageExist = SeleniumCommon.isElementExist(applyButtonOnJD1PageLocator);
			if (isApplyButtonOnJD1PageExist) {
				Log.getLogger().info("Clicking on apply button on JD 1 page");
				Boolean isClickedOnApplyButton = SeleniumCommon.clickOnElement(applyButtonOnJD1PageLocator);
				if (!isClickedOnApplyButton) {
					Boolean isApplyButtonEnabled = driver.findElement(applyButtonOnJD1PageLocator).isEnabled();
					if (!isApplyButtonEnabled) {
						Log.getLogger().info("isApplyButtonEnabled: " + isApplyButtonEnabled);
						Log.getLogger().info("Apply button is disabled- skip test");
						throw new SkipException("Apply button is disabled - Skipping this exception");
					}

				}
			}
		}
        
        String jobId= TestConfiguration.getPropertyValue("chatbot.JobId");
        String websiteUrl=TestConfiguration.getWebsiteUrl();
    	String expectedUrl=websiteUrl+"webportal/#/job/"+jobId+"";
		SeleniumCommon.waitForURL(expectedUrl);
		String actualUrl=driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl);
     
    	
	}
    
    
    
    /**
	 * Identify whether apply job by index number or job ID or Test job based on users input
	 * 
	 * @param JobIdInput input received from user 
	 * @return return array
	 */
	public static int[] getApplyJobByMethod(String JobIdInput) {

		int jobDetails[] = new int[2];
		// index 0th => 1 for apply job by jobId, 2 for apply job by index
		// index 1th = value either job index or job ID

		int testJobID = Integer.parseInt(TestConfiguration.getTestJobId());

		Pattern pattern = Pattern.compile("[0-9]*");

		if (!JobIdInput.isBlank()) {

			Matcher matcher = pattern.matcher(JobIdInput);

			if (JobIdInput.equalsIgnoreCase("Test")) {
				jobDetails[0] = 1;
				jobDetails[1] = testJobID;
			} else if (matcher.matches()) {
				if (JobIdInput.contentEquals("0")) {
					jobDetails[0] = 1;
					jobDetails[1] = testJobID;
				} else {
					jobDetails[0] = 1;
					jobDetails[1] = Integer.parseInt(JobIdInput);
				}
			} else if (JobIdInput.contains("#")) {
				String strIndex[] = JobIdInput.split("#");
				for (String str : strIndex) {
					if (!str.isBlank()) {
						jobDetails[0] = 2; // apply job by index number
						int indexNumber = Integer.parseInt(str);
						if (indexNumber == 0) {
							indexNumber = 1; // // Get index number is zero then change 1 by default
						}
						jobDetails[1] = indexNumber;
					}
				}

			} else {
				jobDetails[0] = 1;
				jobDetails[1] = testJobID; 
			}

		} else {
			jobDetails[0] = 1;
			jobDetails[1] = testJobID; 
		}

		return jobDetails;

	}
	

    
    
    
	
	
	
	

}
