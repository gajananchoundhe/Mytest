package com.shortlist.pages.candidate;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestReport;

public class PsychometricPage {

	WebDriver driver = null;

	//@FindBy(how = How.CSS, using = "button.custom-i-am-ready-button")
	//private WebElement iAmReadyButton;

	public PsychometricPage() // Constructor to initialize Web elements using Page factory
	{
		driver = SeleniumCommon.getDriverInstance();
		//PageFactory.initElements(new AjaxElementLocatorFactory(driver, 60), this);
	}

	public void startPsychometricTest() {

		//driver.navigate().to("https://qa.shortlist.net/webportal/#/job/1400/personality");
		
		Log.getLogger().info("Psychometric Assessment started ..");
		SeleniumCommon.waitForSecond(5);
		SeleniumCommon.waitForPageLoad();
		TestReport.startTest("Verify Psychometric assessment");

		By personalityInsightsTitleElement = By.xpath("//p[contains(text(),'Personality insights')]");
		Boolean isTitlePresentOnPage = SeleniumCommon.isElementExist(personalityInsightsTitleElement);
		Log.getLogger().info("isTitlePresentOnPage: " + isTitlePresentOnPage);
		if(!isTitlePresentOnPage)
		{
			Assert.fail("Psychometric page not found");
		}

		By letBeginButtonElement = By.xpath("//span[text()=\"Let's begin!\"]");
		SeleniumCommon.clickOnElement(letBeginButtonElement);
		SeleniumCommon.waitForPageLoad();
		
		HashMap<Integer, int[]> psychomatriOrderChoice=GenerateTestData.getPsychomatricChoiceOrder();

		int currentQuestionNumber = 1;
		while (currentQuestionNumber <= 16) {

			Log.getLogger().info("Inside loop");
			//Log.getLogger().info("currentQuestionNumber: " + currentQuestionNumber);
			int CurrentQuestionCount=getCurrentQuestionNumber();
			Log.getLogger().info("currentQuestionNumber : CurrentQuestionCount-> " + currentQuestionNumber + " : "+ CurrentQuestionCount);
			
			int order[]=psychomatriOrderChoice.get(currentQuestionNumber);
			
			Log.getLogger().info("Answer order:-> "+currentQuestionNumber + "  "+ order[0]+","+order[1]+","+order[2]+","+order[3]);

			By checkbox1Element = By.xpath(
					"//app-job-home[1]/div[2]/div[2]/app-personality[1]/div[1]/div[2]/div[1]/div[1]/div["+order[0]+"]/label[1]/mat-checkbox[1]/label[1]/div[1]");
			By checkbox2Element = By.xpath(
					"//app-job-home[1]/div[2]/div[2]/app-personality[1]/div[1]/div[2]/div[1]/div[1]/div["+order[1]+"]/label[1]/mat-checkbox[1]/label[1]/div[1]");
			By checkbox3Element = By.xpath(
					"//app-job-home[1]/div[2]/div[2]/app-personality[1]/div[1]/div[2]/div[1]/div[1]/div["+order[2]+"]/label[1]/mat-checkbox[1]/label[1]/div[1]");
			By checkbox4Element = By.xpath(
					"//app-job-home[1]/div[2]/div[2]/app-personality[1]/div[1]/div[2]/div[1]/div[1]/div["+order[3]+"]/label[1]/mat-checkbox[1]/label[1]/div[1]");
			/*
			 * SeleniumCommon.isElementExist(checkbox1Element);
			 * SeleniumCommon.isElementExist(checkbox2Element);
			 * SeleniumCommon.isElementExist(checkbox3Element);
			 * SeleniumCommon.isElementExist(checkbox4Element);
			 * driver.findElement(checkbox1Element).click();
			 * driver.findElement(checkbox2Element).click();
			 * driver.findElement(checkbox3Element).click();
			 * driver.findElement(checkbox4Element).click();
			 */
			
			SeleniumCommon.clickOnElement(checkbox1Element);
			SeleniumCommon.clickOnElement(checkbox2Element);
			SeleniumCommon.clickOnElement(checkbox3Element);
			SeleniumCommon.clickOnElement(checkbox4Element);

			if (currentQuestionNumber == 16) {
				
				TestReport.testPassWithScreenshot("Submitting Psychometri assessment");
				
				By submitButton = By
						.xpath("//button[@class=\"submit-btn mat-raised-button mat-primary ng-star-inserted\"]");
				Boolean IsTestSubmitted = SeleniumCommon.clickOnElement(submitButton);
				if (IsTestSubmitted) {
					Log.getLogger().info("--- Psychometri assessement submitted ---");
					TestReport.testPassWithScreenshot("Psychometri assessement submitted");
				} else {
					Log.getLogger().info("--- Psychometri assessement not submitted ---");
					Assert.fail("Psychometri assessement not submitted");
				}
			} else {

				By nextButtonElement = By
						.xpath("//button[@class=\"next-btn mat-raised-button mat-primary ng-star-inserted\"]");
				/*
				 * SeleniumCommon.isElementExist(nextButtonElement);
				 * driver.findElement(nextButtonElement).click();
				 */
				SeleniumCommon.clickOnElement(nextButtonElement);
				Log.getLogger().info("Clicked on next button");
			}

			currentQuestionNumber++;
			SeleniumCommon.waitForPageLoad();

		}

	}
	
	public int getCurrentQuestionNumber()
	{
		By questionNumberTextElement=By.xpath("//p[@class=\"question-no\"]/span[1]");
		SeleniumCommon.isElementExist(questionNumberTextElement);
		
		String questionText= driver.findElement(questionNumberTextElement).getText();
		String questionCount[] = questionText.split("/");
		int currentQuestionCount = Integer.parseInt(questionCount[0]);
		//Log.getLogger().info("CurrentQuestionCount:" + currentQuestionCount);
		
		return currentQuestionCount;
	}

}
