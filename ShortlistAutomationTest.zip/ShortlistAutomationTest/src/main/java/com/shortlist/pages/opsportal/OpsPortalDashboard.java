package com.shortlist.pages.opsportal;

public class OpsPortalDashboard {

}
