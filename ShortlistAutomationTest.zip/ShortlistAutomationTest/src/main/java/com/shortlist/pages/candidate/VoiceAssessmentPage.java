package com.shortlist.pages.candidate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestReport;

public class VoiceAssessmentPage {

	WebDriver driver = null;
	
		
	By viewQuestionButton=By.xpath("//button[@class=\"mat-raised-button\"]");
	By uploadFileLocator=By.xpath("//input[@type=\"file\"]");
	By UploadVoiceButtonLocator=By.xpath("//div[@class=\"option-text\"]");
	By attachementIcon = By.xpath(
			"//button[@class=\"mat-icon-button mat-primary ng-star-inserted\"]/span/mat-icon[text()=\"attachment\"]");
	By audioPlayerLocator=By.xpath("//div[@class=\"audio-player-section ng-star-inserted\"]/audio");
	By submitMyResponseLocator=By.xpath("//button[@class=\"submit-button mat-stroked-button mat-primary\"]"); 
	

	public VoiceAssessmentPage() // Constructor to initialize Web elements using Page factory
	{
		driver = SeleniumCommon.getDriverInstance();
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 60), this);
	}
	
	
	public void startVoiceAssessment() {

		//driver.navigate().to("https://qa.shortlist.net/webportal/#/job/1400");
		
		TestReport.startTest("Verify voice assessment");
		
		Log.getLogger().info("Voice assessment started ...");
		
		SeleniumCommon.waitForSecond(10);
		String actualPageUrl=driver.getCurrentUrl();
		Log.getLogger().info("Actual Page URL: "+ actualPageUrl);
		

		if (driver.getPageSource().contains("We want to hear your voice!")) {
			Log.getLogger().info("Voice assessment page found");
			TestReport.testPassWithScreenshot("Voice assessment started");
		} else {
			Log.getLogger().info("Voice assessment page not found");
		}

		Boolean isclickedOnViewQuestionButton=SeleniumCommon.clickOnElement(viewQuestionButton);
		if(!isclickedOnViewQuestionButton)
		{
			Log.getLogger().info("Not clicked on View Question button--");
		}
		else {
		 Log.getLogger().info("Clicked on view question button");
		}
		SeleniumCommon.waitForPageLoad();
		
		
		SeleniumCommon.waitForSecond(10);
	    actualPageUrl=driver.getCurrentUrl();
	    String websiteUrl=TestConfiguration.getWebsiteUrl();
	    String jobId=TestConfiguration.getPropertyValue("chatbot.JobId");
	    String expectedUrl=websiteUrl+"webportal/#/job/"+jobId+"/voice";
	    if(expectedUrl.equalsIgnoreCase(actualPageUrl))
	    {
	    	Log.getLogger().info("Actual Url  : "+ actualPageUrl);
	    	Log.getLogger().info("Expected Url: "+ expectedUrl);
	    	
	    }else {
	    	Log.getLogger().info("Actual Url  : "+ actualPageUrl);
	    	Log.getLogger().info("Expected Url: "+ expectedUrl);
	    }
	    
	    TestReport.testPassWithScreenshot("User is redirected to voice upload page");
		
		
		SeleniumCommon.clickOnElement(UploadVoiceButtonLocator);
		SeleniumCommon.clickOnElement(attachementIcon);
		uploadVoiceFile();

		/*
		Boolean isAttachmentIconAvailable = SeleniumCommon.isElementExist(attachementIcon);
		if (isAttachmentIconAvailable) {

			uploadVoiceFile();

		} else {

			Boolean isVoiceFileUploaded = SeleniumCommon.isElementExist(audioPlayerLocator);
			if (isVoiceFileUploaded) {
				Log.getLogger().info("Voice file already uploaded, remove existing file and again upload new file");
				deleteUploadedFile();
				SeleniumCommon.clickOnElement(UploadVoiceButtonLocator);
				SeleniumCommon.clickOnElement(attachementIcon);
				uploadVoiceFile();
				

			} else {
				Log.getLogger().info("Voice file already not uploaded, something went wrong");
			}

		}
		
		*/

	}

	public void uploadVoiceFile() {

		SeleniumCommon.isElementExist(uploadFileLocator);
		String voiceFile = GenerateTestData.getVoiceFileUrl();
		driver.findElement(uploadFileLocator).sendKeys(voiceFile);
		Boolean isVoiceFileUploaded = SeleniumCommon.isElementExist(audioPlayerLocator);
		if (isVoiceFileUploaded) {
			Log.getLogger().info("Voice file uploaded");
		    TestReport.testPassWithScreenshot("Voice file uploaded");
			
			Boolean isClickedOnSubmitButton=SeleniumCommon.clickOnElement(submitMyResponseLocator);
			if(isClickedOnSubmitButton)
			{
				Log.getLogger().info("Voice assessment submitted");
				TestReport.testPassWithScreenshot("Voice assessment submitted");
			}else {
				
				Log.getLogger().info("Voice assessment not submmited");
			}
			
		} else {

			Log.getLogger().info("Voice file not uploaded");
			Assert.fail("Voice file not uploaded");

		}

	}

	public void deleteUploadedFile() {

		Log.getLogger().info("Delete uploaded file");
		By deleteFileUploadedButton = By.xpath("//button/span[text()=\"Delete & Try again\"]");
		SeleniumCommon.clickOnElement(deleteFileUploadedButton);

	}

}
