package com.shortlist.pages.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestReport;

public class LoginSignUpPage {

    WebDriver driver = null;

    
    String emailAddress="";
    String password_="";

    @FindBy(how = How.NAME, using = "userName")
    private WebElement usernameInputField;

    @FindBy(how = How.NAME, using = "password")
    private WebElement passwordInputField;

    @FindBy(how = How.XPATH, using = "//button/span[text()=\" LOG IN \"]")
    private WebElement loginButton;


    
    @FindBy(how = How.XPATH, using = "//button[@type=\"submit\"]")
    private WebElement signUpSubmitButton;


    public LoginSignUpPage()  // Constructor to initialize Web elements using Page factory
    {
        driver = SeleniumCommon.getDriverInstance();
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
    }


    public void login() {
    	
    	emailAddress=TestConfiguration.getCandidateLoginUsername();
    	password_=TestConfiguration.getCandidateLoginPassword();
    	
    	TestReport.startTest("Verify candidate login", "Verify user is able to login with valid login credentials");
    	
        Log.getLogger().info("Username: " + emailAddress);
        Log.getLogger().info("Password: " + password_);
        usernameInputField.sendKeys(emailAddress);
        passwordInputField.sendKeys(password_);
        Log.getLogger().info("Entered username and password");
        TestReport.testInfo("Username : "+ emailAddress);
        TestReport.testInfo("Password : "+ password_);
        loginButton.click();
        SeleniumCommon.waitForSecond(6);
        if(driver.getPageSource().contains("Continue as"))
        {
        	Log.getLogger().info("Select either candidate or employer button");
        	SeleniumCommon.clickOnElement(By.xpath("//span[contains(text(),'CANDIDATE')]"));
        	//SeleniumCommon.clickOnElement(By.xpath("//span[contains(text(),'EMPLOYER')]"));
        }
        
        
        String actualPageUrl = driver.getCurrentUrl();
        String expectedPageUrl=TestConfiguration.getWebsiteUrl()+"webportal/#/dashboard/all-jobs";
        SeleniumCommon.waitForURL(expectedPageUrl);
        Assert.assertEquals(actualPageUrl, expectedPageUrl);
        
         
    }
    
    
    
    


    public void fillSignUpFormAndSubmit()
    {
    	TestReport.startTest("Verify candidate signup");
    	
    	password_=TestConfiguration.getSignupPassword();
    	emailAddress=GenerateTestData.getEmailAddress();
    	
        By signUpButton =By.xpath("//div[@class=\"signup-toggle ng-star-inserted\"]/button/span");
        SeleniumCommon.clickOnElement(signUpButton);
        
      
        By titleLocator=By.xpath("//h2[@class=\"login-header\"]");
        SeleniumCommon.isElementExist(titleLocator);
        
        Log.info("Sign up form filling started");
        
        String Title=driver.findElement(titleLocator).getText();
        Log.getLogger().info("Title on SignUp Page :"+ Title);
        //Assert.assertEquals(Title,"Candidate sign up");
        
        Log.getLogger().info("Generated Email Address :"+emailAddress);
        Log.getLogger().info("Password :"+password_);
        String name=GenerateTestData.getName();
        
        By nameLocator=By.name("fullName");
        SeleniumCommon.isElementExist(nameLocator);
        driver.findElement(nameLocator).sendKeys(name);
        Log.getLogger().info("Name entered");
        
        By emailLocator=By.name("userName");
        SeleniumCommon.isElementExist(emailLocator);
        driver.findElement(emailLocator).sendKeys(emailAddress);
        Log.getLogger().info("Email entered");
        
        By passwordLocator=By.name("password");
        SeleniumCommon.isElementExist(passwordLocator);
        driver.findElement(passwordLocator).sendKeys(password_);
        Log.getLogger().info("Password entered");
        
        SeleniumCommon.clickOnElement(By.name("gdprSignupCheckbox"));
        Log.getLogger().info("Checkboc checked");
        
        TestReport.testInfo("Email:"+ emailAddress);
        TestReport.testInfo("Password:"+ password_);
        TestReport.testPassWithScreenshot("Signup form filled and submitting");
        
        SeleniumCommon.clickOnElement(By.xpath("//button[@type=\"submit\"]"));
        Log.getLogger().info("Clicked on signup button");
      
        
        

        SeleniumCommon.waitForSecond(4);

        if(driver.getPageSource().contains("You’ve registered with that email already."))
        {
        	TestReport.testPassWithScreenshot("You have registered with that email already");
            Log.getLogger().info("You’ve registered with that email already");
            emailAddress=GenerateTestData.getEmailAddress();
            Log.getLogger().info("Again generated Email Address :"+ emailAddress);
            driver.findElement(emailLocator).clear();
            driver.findElement(emailLocator).sendKeys(emailAddress);
            SeleniumCommon.clickOnElement(By.xpath("//button[@type=\"submit\"]"));
        }

        SeleniumCommon.waitForSecond(6);
        String actualPageUrl = driver.getCurrentUrl();
        String expectedPageUrl=TestConfiguration.getWebsiteUrl()+"webportal/#/dashboard/all-jobs";
        SeleniumCommon.waitForURL(expectedPageUrl);
        Assert.assertEquals(actualPageUrl, expectedPageUrl);


    }

}
