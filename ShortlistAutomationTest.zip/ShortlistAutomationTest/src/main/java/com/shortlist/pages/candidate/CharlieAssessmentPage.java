package com.shortlist.pages.candidate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.SkipException;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestReport;

public class CharlieAssessmentPage {

	WebDriver driver = null;

	@FindBy(how = How.CSS, using = "button.custom-i-am-ready-button")
	private WebElement iAmReadyButton;
	

	public CharlieAssessmentPage() // Constructor to initialize Web elements using Page factory
	{
		driver = SeleniumCommon.getDriverInstance();
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 60), this);
	}

	public void startCharlieAssessment() {

		if (TestConfiguration.isKeyExistInProperty("Charlie.assessment.execute")) {
			String charlieTestSkipStatus = TestConfiguration.getPropertyValue("Charlie.assessment.execute");
			if (charlieTestSkipStatus.equalsIgnoreCase("skip")) {
				Log.getLogger()
						.info("Charlie assessment test skipped due to candidate not qualified in chatbot response");
				throw new SkipException(
						"Charlie assessment test skipped due to candidate not qualified in chatbot response");
			}
		}
		
		Log.getLogger().info("Charlie assessment started ...");
		TestReport.startTest("Verify charlie assessment");
		
		//driver.navigate().to("https://charlieqa.shortlist.net/5e2d66df52faff0001c7f69a");
		SeleniumCommon.waitForPageLoad();
		SeleniumCommon.waitForSecond(5);
		
		By startChatButtonLocator=By.xpath("//button[@class=\"mat-raised-button\"]");
		SeleniumCommon.clickOnElement(startChatButtonLocator);
		
		SeleniumCommon.waitForPageLoad();
	
		
		 By iAmReadyButtonLocator=By.xpath("//button[@class=\"custom-i-am-ready-button smt-btn-bottom mat-raised-button mat-primary\"]");
		 By playArrowIcon1Locator=By.xpath("//button[@class=\"custom-fab-button mat-fab mat-accent\"]");
		 By playArrowIcon2Locator=By.xpath("(//button[@class=\"custom-fab-button mat-fab mat-accent\"])[2]");
		 By startAssingmentLocator=By.xpath("//span[contains(text(),'START ASSESSMENT')]");
		 
		 SeleniumCommon.waitForSecond(5);
		 
		 SeleniumCommon.clickOnElement(iAmReadyButtonLocator);
		 SeleniumCommon.waitForSecond(5);
		 SeleniumCommon.clickOnElement(playArrowIcon1Locator);
		 SeleniumCommon.waitForSecond(5);
		 SeleniumCommon.clickOnElement(playArrowIcon2Locator);
		 SeleniumCommon.waitForSecond(5);
		 Boolean isTestStart= SeleniumCommon.clickOnElement(startAssingmentLocator);
		if (isTestStart) {
			Log.getLogger().info("Assessment started");
			TestReport.testPassWithScreenshot("Charlie assessment started");
		} else {

			Log.getLogger().info("Assessment not started, something went wrong");
		}
		
		SeleniumCommon.waitForSecond(5);
		if(driver.getPageSource().contains("Keep an eye on the time"))
		{
			Log.getLogger().info("Timer alert found");
			Boolean isClickedOnContinueButton=SeleniumCommon.clickOnElement(By.xpath("//text()[.='Continue']/ancestor::button[1]"));
			Log.getLogger().info("isClickedOnContinueButton: "+isClickedOnContinueButton);
			
		}
		
		
		SeleniumCommon.waitForPageLoad();
		
		By resumeConfimrationPopup=By.xpath("//button[@class=\"charlie-confirm-button mat-button mat-primary\"]/span[text()=\"Resume\"]");
		Boolean isConfirmPopupExist=SeleniumCommon.isElementExist(resumeConfimrationPopup);
		if(isConfirmPopupExist)
		{
			//driver.findElement(resumeConfimrationPopup).click();
			SeleniumCommon.clickOnElement(resumeConfimrationPopup);
		}
		

		int totalQuestionCount = 0, currentQuestionNo = 0;
		
		int arrLen[]=getTotalQuestionCountNew();
		totalQuestionCount = arrLen[0];
		currentQuestionNo = arrLen[1];

		
		while (currentQuestionNo <= totalQuestionCount) {

			
			Log.getLogger().info("inside loop");
			Log.getLogger().info("currentQuestionNo: "+ currentQuestionNo);
			//QuestionType questionType = getQuestionType();
			QuestionType questionType=getQuestion2();
			Log.getLogger().info("****** ***  *** Question Type: "+ questionType);
			
			sendInput(questionType,currentQuestionNo);		
			
			

			SeleniumCommon.waitForPageLoad();

			currentQuestionNo++;
			
			

		}

		 Log.getLogger().info("currentQuestionNo: " + currentQuestionNo);
		 Log.getLogger().info("totalQuestionCount: " + totalQuestionCount);
		if (--currentQuestionNo == totalQuestionCount) {
						
						
			Log.getLogger().info("Assigement completed inside");
			Log.getLogger().info("currentQuestionNo: " + currentQuestionNo);
			 Log.getLogger().info("totalQuestionCount: " + totalQuestionCount);

			By submitAndNextButton = By.xpath("(//button/span[text()=\"SUBMIT & NEXT\"])[1]"); // Submit and next button
			Boolean isSubmitButtonFound = SeleniumCommon.isElementExist(submitAndNextButton);
			Log.getLogger().info("isSubmitButtonFound: "+ isSubmitButtonFound);
			if(!isSubmitButtonFound)
			{
				Log.getLogger().info("Submit assessment button not found - check any question need to respond");
				int arrLen2[]=getTotalQuestionCountNew();
				totalQuestionCount = arrLen2[0];
				currentQuestionNo = arrLen2[1];
				if(totalQuestionCount==currentQuestionNo)
				{
					QuestionType questionType=getQuestion2();
					Log.getLogger().info("Check last Question Type: "+ questionType);
					sendInput(questionType,currentQuestionNo);
				}
				
				
			}
			isSubmitButtonFound=SeleniumCommon.isElementExist(submitAndNextButton);
			Log.getLogger().info("isSubmitButtonFound: " + isSubmitButtonFound);
			
			
			 TestReport.testPassWithScreenshot("Submitting charlie assessment");
			//driver.findElement(submitAndNextButton).click();
			 Boolean isClickedOnSubmitNextButton=SeleniumCommon.clickOnElement(submitAndNextButton);
			 if(!isClickedOnSubmitNextButton)
			 {
				 Log.getLogger().info("Not clicked on submit charlie assessment button");
				 SeleniumCommon.isElementExist(submitAndNextButton);
				 Boolean isEnabledSubmitButton=driver.findElement(submitAndNextButton).isEnabled();
				 Log.getLogger().info("isEnabledSubmitButton: "+ isEnabledSubmitButton);
				 if(isEnabledSubmitButton)
				 {
					 SeleniumCommon.clickOnElement(submitAndNextButton);
				 }
			 }
			 
			

			By skipButton = By.xpath("//span[text()=\"SKIP\"]"); // Skip feedback
			//SeleniumCommon.isElementExist(skipButton);
			SeleniumCommon.clickOnElement(skipButton);
		} else {
			Log.getLogger().info("currentQuestionNo: " + currentQuestionNo);
			Log.getLogger().info("totalQuestionCount: " + totalQuestionCount);
			Log.getLogger().info("No of question mismatch-check count");
		}

	}

	
	
	public void sendInput(QuestionType questionType, int currentQuestionNo) {
		
		if(questionType==QuestionType.NONE)
		{
			SeleniumCommon.takeScreenshot();
			Log.getLogger().info("------ Screenshot taken-----  Question No->"+ currentQuestionNo);
			SeleniumCommon.waitForSecond(5);
		    questionType=getQuestion2();  //Repeat call to check which question
		}

		if (questionType == QuestionType.OPTION) {

			Log.getLogger().info("currentQuestionNo:" + currentQuestionNo);
			By singleSelectOptionElement = By.xpath("//span[text()=\"A\"]");
			//SeleniumCommon.isElementExist(singleSelectOptionElement);
			//driver.findElement(singleSelectOptionElement).click();
			SeleniumCommon.clickOnElement(singleSelectOptionElement);
			Log.getLogger().info("Clicked on option");

			By submitButtonElement = By.xpath("//button/span[text()=\"SUBMIT\"]");
			//SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button");

			// SeleniumCommon.waitForPageLoad();
			

		}

		if (questionType == questionType.TEXTEDITOR1) {

			// Answer text editor 1
			Log.getLogger().info("Free text 1 inside");

			By textEditor1Element = By.xpath("(//div[@data-placeholder=\"Insert text here ...\"])[5]/p");
			SeleniumCommon.isElementExist(textEditor1Element);
			driver.findElement(textEditor1Element).sendKeys("This is test test");

			By submitButton2 = By
					.xpath("(//app-comprehension-subquestion/div[1]/div/div[2]/div/button[1]/span/span)[3]");
			//driver.findElement(submitButton2).click();
			SeleniumCommon.clickOnElement(submitButton2);

			Log.getLogger().info("Clicked on submit button");

		}
		if (questionType == QuestionType.TEXTEDITOR2) {

			// Answer text editor 2
			By textEditor2Element = By.xpath("//div[@data-placeholder=\"Insert text here ...\"]/p");
			SeleniumCommon.isElementExist(textEditor2Element);
			driver.findElement(textEditor2Element).sendKeys("This is editor 2 test descipriton");
			By submitOption3 = By
					.xpath("(//div[@class=\"button-row\"]/button/span[@class=\"mat-button-wrapper\"])[1]");
			//driver.findElement(submitOption3).click();
			SeleniumCommon.clickOnElement(submitOption3);
			Log.getLogger().info("Clicked on submit button");

		}

		if (questionType == QuestionType.FILLINTHEBLANK) {

			// Fill in the blank
			By fillInTheBlankTextElement = By.xpath("//input[@placeholder=\"Start typing...\"]");
			SeleniumCommon.isElementExist(fillInTheBlankTextElement);
			driver.findElement(fillInTheBlankTextElement).sendKeys("This is text for fill in the blank");
			Log.getLogger().info("Text entered ..");
			By submitButtonElement = By.xpath("//button/span[text()=\"SUBMIT\"]");
			//SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button");

		}

		if (questionType == QuestionType.UPLOADFILE) {

			// File upload
			// By uploadFileTextElement = By.xpath("//span[text()=\"FILE UPLOAD\"]");
			By uploadFileElement = By.xpath("//input[@type=\"file\"]");
            Log.info("Inside upload if ");
			  //driver.findElement(By.xpath("//div[text()=\"UPLOAD FILE\"]")).click();
			//---SeleniumCommon.clickOnElement(By.xpath("//div[text()=\"UPLOAD FILE\"]")); 
			// JavascriptExecutor jse = (JavascriptExecutor)driver;
			// jse.executeScript("document.getElementsByTagName(\"input\")[0].removeAttribute('hidden');");
			Log.info("clicked on upload file ");
			String fileURL= GenerateTestData.getResumeUrl();
			SeleniumCommon.isElementExist(uploadFileElement);
			driver.findElement(uploadFileElement).sendKeys(fileURL);

			//SeleniumCommon.pressEscapeKey();
			CloseProctoringPopup();

			By fileUploadedElement = By.xpath("//div[@class=\"charlie-question-file-upload-file\"]");
			Boolean isFileUploaded = SeleniumCommon.isElementExist(fileUploadedElement);
			if (isFileUploaded) {
				Log.getLogger().info("File uploadeded");
			} else {
				Log.getLogger().info("File not uploadeded");
			}
			By submitButtonElement = By.xpath("//button/span[text()=\"SUBMIT\"]");
			//SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button");

		}
		
		if(questionType == QuestionType.CASESTUDY_FILE_UPLOAD)
		{
			
			// File upload
			// By uploadFileTextElement = By.xpath("//span[text()=\"FILE UPLOAD\"]");
			By uploadFileElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-file-upload-input[1]/div[1]/div[1]/div[1]/div[1]/input[@type=\"file\"]");
			
			
            Log.info("Inside case study upload if ");
            By uploadTextElement= By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-file-upload-input[1]/div[1]/div[1]/div[1]/div[1]/button[1]/span[1]/div[text()=\"UPLOAD FILE\"]");
            SeleniumCommon.clickOnElement(uploadTextElement);
            //SeleniumCommon.isElementExist(uploadTextElement);
			//driver.findElement(uploadTextElement).click();
            CloseProctoringPopup();
			// JavascriptExecutor jse = (JavascriptExecutor)driver;
			// jse.executeScript("document.getElementsByTagName(\"input\")[0].removeAttribute('hidden');");
			Log.info("clicked on upload file ");
			String fileURL= GenerateTestData.getResumeUrl();
			SeleniumCommon.isElementExist(uploadFileElement);
			driver.findElement(uploadFileElement).sendKeys(fileURL);

			SeleniumCommon.pressEscapeKey();
			CloseProctoringPopup();

			By fileUploadedElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-file-upload-input[1]/div[1]/div[2]/div[@class=\"charlie-question-file-upload-file\"]");
			Boolean isFileUploaded = SeleniumCommon.isElementExist(fileUploadedElement);
			if (isFileUploaded) {
				Log.getLogger().info("File uploadeded");
			} else {
				Log.getLogger().info("File not uploadeded");
			}
			By submitButtonElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span/span[text()=\"SUBMIT\"]");
			//SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button");
		}
		
		if (questionType == QuestionType.CASESTUDY_SINGLE_OPTION) {

			Log.getLogger().info("INSIDE CASE STUDY SINGLE OPTION");
			
			By optionsList=By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-mcq-options[1]/div");
			SeleniumCommon.isElementExist(optionsList);
			int noOfOptionsAvailable=driver.findElements(optionsList).size();
			Log.getLogger().info("noOfOptionsAvailable: "+ noOfOptionsAvailable);
			if(noOfOptionsAvailable==0)
			{
				SeleniumCommon.scrollVertical();
				SeleniumCommon.isElementExist(optionsList);
				noOfOptionsAvailable=driver.findElements(optionsList).size();
				Log.getLogger().info("noOfOptionsAvailable: "+ noOfOptionsAvailable);
				Log.getLogger().info("Inside scroll if block");
				
			}
			int randomOptionNumber=GenerateTestData.getRandomNumber(noOfOptionsAvailable);
			
			By randomOptionElement=By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-mcq-options[1]/div["+randomOptionNumber+"]/div[1]/span[1]/button");
			//SeleniumCommon.isElementExist(randomOptionElement);
			//driver.findElement(randomOptionElement).click();
			SeleniumCommon.clickOnElement(randomOptionElement);
			Log.getLogger().info("Clicked on option");

			By submitButtonElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span/span[text()=\"SUBMIT\"]");
			SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			boolean isClickedOnSubmitButton=  SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button: "+ isClickedOnSubmitButton);


		}
		
		
		if (questionType == QuestionType.CASESTUDY_MULTIPLE_OPTION) {

			Log.getLogger().info("INSIDE CASE STUDY MULTIPLE OPTION");
			
			By optionsList=By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-mcq-options[1]/div");
			SeleniumCommon.isElementExist(optionsList);
			int noOfOptionsAvailable=driver.findElements(optionsList).size();
			Log.getLogger().info("noOfOptionsAvailable: "+ noOfOptionsAvailable);
			if(noOfOptionsAvailable==0)
			{
				SeleniumCommon.scrollVertical();
				SeleniumCommon.isElementExist(optionsList);
				noOfOptionsAvailable=driver.findElements(optionsList).size();
				Log.getLogger().info("noOfOptionsAvailable: "+ noOfOptionsAvailable);
				Log.getLogger().info("Inside scroll if block");
				
			}
			int randomOptionNumber1=GenerateTestData.getRandomNumber(noOfOptionsAvailable);
			int randomOptionNumber2=GenerateTestData.getRandomNumber(noOfOptionsAvailable);
			if(randomOptionNumber1==randomOptionNumber2)
			{
				randomOptionNumber2=GenerateTestData.getRandomNumber(noOfOptionsAvailable);
			}
			
			By randomOption1Element=By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-mcq-options[1]/div["+randomOptionNumber1+"]/div[1]/span[1]/button");
			//SeleniumCommon.isElementExist(randomOption1Element);
			//driver.findElement(randomOption1Element).click();
			SeleniumCommon.clickOnElement(randomOption1Element);
			Log.getLogger().info("Clicked on option ");
			
			By randomOption2Element=By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[1]/div[1]/div[5]/app-mcq-options[1]/div["+randomOptionNumber2+"]/div[1]/span[1]/button");
			//SeleniumCommon.isElementExist(randomOption2Element);
			//driver.findElement(randomOption2Element).click();
			SeleniumCommon.clickOnElement(randomOption2Element);
			Log.getLogger().info("Clicked on option ");

			By submitButtonElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span/span[text()=\"SUBMIT\"]");
			SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			boolean isClickedOnSubmitButton=  SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button: "+ isClickedOnSubmitButton);


		}
		
		if (questionType == QuestionType.CASESTUDY_FILLINTHEBLANK) {

			// Fill in the blank
			By fillInTheBlankTextElement = By.xpath("//input[@id=\"mat-input-0\"]");
		    boolean isElementFound=SeleniumCommon.isElementExist(fillInTheBlankTextElement);
		    if(!isElementFound)
		    {
		    	//TODO add flag instead of code to check whether previously fill in the blank appeared or not 
		    	driver.navigate().refresh();
		    	SeleniumCommon.waitForPageLoad();
		    	SeleniumCommon.isElementExist(fillInTheBlankTextElement);
		    }
			driver.findElement(fillInTheBlankTextElement).sendKeys("This is text for fill in the blank");
			Log.getLogger().info("Text entered ..");
			By submitButtonElement = By.xpath("//mat-card[1]/mat-card-content[1]/app-comprehension[1]/div[1]/div[1]/app-comprehension-subquestion[1]/div[1]/div[1]/div[2]/div[1]/button[1]/span/span[text()=\"SUBMIT\"]");
			//SeleniumCommon.isElementExist(submitButtonElement);
			//driver.findElement(submitButtonElement).click();
			SeleniumCommon.clickOnElement(submitButtonElement);
			Log.getLogger().info("Clicked on submit button");

		}
		

		
		
	}
	
	
	public void CloseProctoringPopup() {
		
		SeleniumCommon.waitForSecond(4);
		if(driver.getPageSource().contains("In order to continue the assessment you need to revert to the full screen mode"))
		{   
			Log.getLogger().info("Proctoring warning alert found");
			By resumeConfimrationPopup=By.xpath("//button[@class=\"charlie-confirm-button mat-button mat-primary\"]/span[text()=\"Resume\"]");
			SeleniumCommon.clickOnElement(resumeConfimrationPopup);
		}else {
			Log.getLogger().info("Proctoring warning alert not found");
		}
	}
	
	
	
	
	
	public QuestionType getQuestion2() {
		
		SeleniumCommon.waitForSecond(4);
		
		QuestionType queType = QuestionType.NONE;
		
		Boolean optionElement =driver.getPageSource().contains("Select one option");
		Boolean optionElement2 =driver.getPageSource().contains("SELECT ONE OPTION");
	   	Boolean optionMultipleElement= driver.getPageSource().contains("SELECT ALL THE RELEVANT CHOICES TO GET FULL MARKS");
		Boolean textEditor1Element =driver.getPageSource().contains("READ THIS INFORMATION FOR THE NEXT FEW QUESTIONS");
		Boolean textEditor2Element =driver.getPageSource().contains("Answer in 50-250 words");
		Boolean fillInTheBlankElement =driver.getPageSource().contains("FILL IN THE BLANK");
		Boolean uploaFileElement =driver.getPageSource().contains("FILE UPLOAD");
		Boolean uploaFileElement2 =driver.getPageSource().contains("UPLOAD FILE");
		
		if(optionElement || optionElement2)
		{
			queType=QuestionType.OPTION;
			Log.getLogger().info(" -- SINGLE OPTION --");
		}
		
		if(optionMultipleElement)
		{
			queType=QuestionType.OPTION;
			Log.getLogger().info(" -- MULTIPLE OPTION --");
		}
		
		
		if(textEditor1Element)
		{
			queType=QuestionType.TEXTEDITOR1;
			Log.getLogger().info(" -- TEXTEDITOR1 --");
		}
		
		if(textEditor2Element)
		{
			if(!textEditor1Element)
			{
				queType=QuestionType.TEXTEDITOR2;
				Log.getLogger().info(" -- TEXTEDITOR2 --");
			}
		}
		
		if(fillInTheBlankElement)
		{
			queType=QuestionType.FILLINTHEBLANK;
			Log.getLogger().info(" -- FILL IN THE BLANK --");
		}
		
		if(uploaFileElement)
		{
			queType=QuestionType.UPLOADFILE;
			Log.getLogger().info(" -- UPLOAD FILE --");
		}
		
		
		if(textEditor1Element && fillInTheBlankElement)
		{
			queType=QuestionType.CASESTUDY_FILLINTHEBLANK;
			Log.getLogger().info("-- CASESTUDY FILLE IN THE BLANK --");
		}
		
		if(textEditor1Element && optionElement)
		{
			queType=QuestionType.CASESTUDY_SINGLE_OPTION;
			Log.getLogger().info(" -- CASESTUDY SINGLE OPTION --");
		}
		
		if(textEditor1Element && optionMultipleElement)
		{
			queType=QuestionType.CASESTUDY_MULTIPLE_OPTION;
			Log.getLogger().info(" -- CASESTUDY MULTIPLE OTION --");
		}
		
		if(textEditor1Element && uploaFileElement2)
		{
			queType=QuestionType.CASESTUDY_FILE_UPLOAD;
			Log.getLogger().info(" -- CASESTUDY FILE UPLOAD --");
		}
		
		
		
		return queType;
		
		
	}

	public int getTotalQuestionCount() {

		SeleniumCommon.waitForSecond(5);

		// boolean exists =
		// driver.findElements(By.xpath("//div[@class=\"custom-hello-msg\"]")).size() !=
		// 0;
		boolean exists = SeleniumCommon.isElementExist(By.xpath("//div[@class=\"custom-hello-msg\"]"));
		Log.getLogger().info("custom-hello-msg:" + exists);
		String questionCountText = "";
		if (exists) {
			questionCountText = driver.findElement(By.className("custom-hello-msg")).getText();
		} else {
			questionCountText = driver
					.findElement(By
							.xpath("(//span[@class=\"custom-hello-msg\" or @class=\"custom-hello-msg fontsz24\"])[1]"))
					.getAttribute("innerHTML");
		}

		Log.getLogger().info("questionCountText:" + questionCountText);
		String questionCount[] = questionCountText.split("/");
		int totalQuestionCount = Integer.parseInt(questionCount[1]);
		Log.getLogger().info("totalQuestionCount:" + totalQuestionCount);
		return totalQuestionCount;
	}

	public int getCurrentQuestionNo() {

		SeleniumCommon.waitForSecond(5);

		// boolean exists =
		// driver.findElements(By.xpath("//div[@class=\"custom-hello-msg\"]")).size() !=
		// 0;
		boolean exists = SeleniumCommon.isElementExist(By.xpath("//div[@class=\"custom-hello-msg\"]"));
		String questionCountText = "";
		if (exists) {
			questionCountText = driver.findElement(By.className("custom-hello-msg")).getText();
		} else {
			questionCountText = driver
					.findElement(By
							.xpath("(//span[@class=\"custom-hello-msg\" or @class=\"custom-hello-msg fontsz24\"])[1]"))
					.getAttribute("innerHTML");
		}

		Log.getLogger().info("questionCountText:" + questionCountText);
		String questionCount[] = questionCountText.split("/");
		int currentQuestionNo = Integer.parseInt(questionCount[0]);
		Log.getLogger().info("Current question No:" + currentQuestionNo);
		return currentQuestionNo;
	}
	
	
	public int[] getTotalQuestionCountNew() {

		SeleniumCommon.waitForSecond(5);

		// boolean exists =
		// driver.findElements(By.xpath("//div[@class=\"custom-hello-msg\"]")).size() !=
		// 0;
		boolean exists = SeleniumCommon.isElementExist(By.xpath("//div[@class=\"custom-hello-msg\"]"));
		Log.getLogger().info("custom-hello-msg:" + exists);
		String questionCountText = "";
		if (exists) {
			questionCountText = driver.findElement(By.className("custom-hello-msg")).getText();
		} else {
			questionCountText = driver
					.findElement(By
							.xpath("(//span[@class=\"custom-hello-msg\" or @class=\"custom-hello-msg fontsz24\"])[1]"))
					.getAttribute("innerHTML");
		}

		Log.getLogger().info("questionCountText:" + questionCountText);
		String questionCount[] = questionCountText.split("/");
		int totalQuestionCount = Integer.parseInt(questionCount[1]);
		Log.getLogger().info("totalQuestionCount:" + totalQuestionCount);
		
		int currentQuestionNo = Integer.parseInt(questionCount[0]);
		Log.getLogger().info("Current question No:" + currentQuestionNo);
		
		int[] intArray = new int[2];
		intArray[0]=totalQuestionCount;
		intArray[1]=currentQuestionNo;
				
		return intArray;
	}

	public enum QuestionType {
		OPTION, TEXTEDITOR1, TEXTEDITOR2, FILLINTHEBLANK, UPLOADFILE, NONE, CASESTUDY_FILE_UPLOAD,CASESTUDY_SINGLE_OPTION,CASESTUDY_FILLINTHEBLANK, CASESTUDY_MULTIPLE_OPTION
	}
}
