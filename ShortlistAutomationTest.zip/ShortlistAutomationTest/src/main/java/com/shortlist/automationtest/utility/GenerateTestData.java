package com.shortlist.automationtest.utility;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class GenerateTestData {
	
	public static int testPassed=0;
	public static int testFailed=0;
	public static int testSkipped=0;
	public static String startTestTime="";
	public static String endTestTime="";
	

   public static String getEmailAddress() {
		
		String userEmail=TestConfiguration.getSignupEmail();
		if(!isEmailValid(userEmail))
		{
			userEmail="gajanan@shortlist.net";
		}
		
		String emailName=userEmail.split("@")[0];
		String emailDomainName=userEmail.split("@")[1];
		
		String randomNumber=getDate("yyyyMMddHHmm");
		String emailAddress = emailName +"+"+ randomNumber + "@"+emailDomainName;
		
		if(!isEmailValid(emailAddress))
		{
			System.out.println("Email not a valid");
		}
				
		return emailAddress;

	}
	
     
	
	public static String getDate()
	{
		ArrayList<String> dateList = new ArrayList<String>();
		dateList.add("02/1985");
		dateList.add("05/1989");
		dateList.add("12/1994");
		dateList.add("08/1988");
		dateList.add("04/1984");
		dateList.add("07/1986");
		dateList.add("03/2008");
		dateList.add("04/2010");

		int number=dateList.size();
		String date=dateList.get(getRandomNumber(number));
		Log.getLogger().info("Generated Date: "+ date);
		return date;
		
	}
	
	public static String getJobTitle() {
		
		String jobTitleList1="Marketing Manager,Marketing Director,Graphic Designer,Marketing Research Analyst,Social Media Assistant,Account Executive,";
		String jobTitleList2="Business Manager,Chief Executive Officer,Human Resources,Chief Technology Officer,Team Leader,Assistant Manager,IT Professional,";
		String jobTitleList3="Cloud Architect,Quality Control,Technical Support Specialist,Customer Care Associate,Account Manager,Business Analyst,";
		String jobTitleList4="UX Designer & UI Developer,SQL Developer,Web Designer,Software Engineer,DevOps Engineer,Computer Programmer,Network Administrator";
		
		jobTitleList1=jobTitleList1.concat(jobTitleList2).concat(jobTitleList3).concat(jobTitleList4);
		
		String []jobtitles=jobTitleList1.split(",");
		String jobTitle=jobtitles[getRandomNumber(jobtitles.length)];
		return jobTitle;
		
	}
	
	public static String getMobileNumber() {
		
		String mobileList1="7696000000,7696099999,8699000000,8699099999,9041000000,9041099999,9216000000,";
		String mobileList2="9217000000,9217099999,9256000000,9256099999,9257000000,9257099999,9216100000,";
		String mobileList3="7696100000,7696199999,8699100000,8699199999,9041100000,9041199999,9216500000,";
		mobileList1=mobileList1.concat(mobileList2).concat(mobileList3);
		String []mobileNumberList=mobileList1.split(",");
		String mobileNo=mobileNumberList[getRandomNumber(mobileNumberList.length)];
		return mobileNo;
		
	}
	
	public static String getEmployerName() {
		
		String employer1="Tata Consultancy Services,Infosys,Wipro,HCL Technologies,Tech Mahindra,Mindtree,Datamatics Global Services,Harbinger Systems,";
		String employer2="KPIT Technologies,Zensar Technologies,LIC Housing Finance,Tata Chemicals,Yes Bank India,Kotak Mahindra Bank,HDFC Bank,";
		String employer3="Bajaj Electricals,Rajesh Exports,Bajaj Finserv,Sun Pharmaceutical,Reliance Communications,Zee Entertainment,";
		employer1=employer1.concat(employer2).concat(employer3);
		String []employerList=employer1.split(",");
		String employerName=employerList[getRandomNumber(employerList.length)];
		return employerName;
		
	}
	
	public static String getExperience() {
		
		return String.valueOf(getRandomNumberFromRange(1,10));
	}
	
	public static String getName() {
		
		String nameList1="Aditya,Arjun,Ashish,Bhaskar,Chiranjeev,Dilip,Gaurav,Gautam,Girish,Gurdeep,";
		String nameList2="Jaideep,Kshitij,Nagesh,Parth,Pavan,Pranav,Rajiv,RiteshSandeep,Sanjay,Varun,";
		String nameList3="James,Michael,Robert,Maria,David,Maria,Ethan,Jacob,William,Daniel,Joseph,";
		nameList1=nameList1.concat(nameList2).concat(nameList3);
		String []nameList=nameList1.split(",");
		String name=nameList[getRandomNumber(nameList.length)];
		return name+" test";
		
	}
	
	
	public static String getActualSalary() {

		String strNumber = "20000,30000,40000,50000,60000,70000,80000,90000";
		String[] num = strNumber.split(",");
		String salRandomRange = num[getRandomNumber(num.length)];

		int minSalary = getRandomNumberFromRange(1, 5);
		salRandomRange = minSalary + salRandomRange;
		minSalary = Integer.parseInt(salRandomRange);
		Log.getLogger().info("minSal: " + minSalary);
		
		return String.valueOf(minSalary);

	}
	
	public static String getExpectedSalary() {
	
		String strNumber = "20000,30000,40000,50000,60000,70000,80000,90000";
		String[] num = strNumber.split(",");
		String salRandomRange = num[getRandomNumber(num.length)];
		salRandomRange = num[getRandomNumber(num.length)];
		int maxSalary = getRandomNumberFromRange(6, 9);
		salRandomRange = maxSalary + salRandomRange;
		maxSalary = Integer.parseInt(salRandomRange);
		Log.getLogger().info("maxSalary: " + maxSalary);
		return String.valueOf(maxSalary);
	}
	
	
	public static String getCity() {
		
		String cityList1="Pune,Mumbai,Navi Mumbai,Delhi,Bangalore,Hyderabad,Ahmedabad,Chennai,Kolkata,Lucknow,";
		String cityList2="Nagpur,Indore,Thane,Bhopal,Nashik,Ludhiana,Aurangabad,Raipur,Solapur,Gurgaon,";
		String cityList3="Kolhapur,Latur,Gandhinagar,Vijayawada,Mysore,Gulbarga,";
		
		cityList1=cityList1.concat(cityList2).concat(cityList3);
		String []cityList=cityList1.split(",");
		String cityName=cityList[getRandomNumber(cityList.length)];
		
		return cityName;
	}
	
	public static String getInstituteName() {
		
		String instituteList="Babasaheb,Banaras,Allahabad,Rajiv,Assam,Delhi,Gujarat,Karnataka,Madhya Pradesh,Maharashtra,Manipal,Tamil Nadu,Balaji";
		String []institutes=instituteList.split(",");
		String instituteName=institutes[getRandomNumber(institutes.length)];
		return instituteName;
	}
	
	
	public static String getResumeUrl() {

		String resumeUrl = new File(System.getProperty("user.dir")).getAbsolutePath()
				+ "\\testdata\\resume-sample1.pdf";
		return resumeUrl;
	}
	
	public static String getPhotoUrl() {

		String photoUrl = new File(System.getProperty("user.dir")).getAbsolutePath()
				+ "\\testdata\\photo1.png";
		return photoUrl;
	}
	
	public static String getVoiceFileUrl() {

		String voiceFileUrl = new File(System.getProperty("user.dir")).getAbsolutePath()
				+ "\\testdata\\REC-voice-sample1.mp3";
		return voiceFileUrl;
	}
	
	public static String getLinkedinUrl() {
		
		final String Url="https://in.linkedin.com/company/shortlist-hires";
		return Url;
	}
	
	
	public static String getJobType() {
		
		String []jobTypeList= {"Part-time","Internship","Personal projects","Fellowship","Full time"};
		String jobType=jobTypeList[getRandomNumber(jobTypeList.length)];
		return jobType;
	}
	
	public static String getFieldName() {

		String[] fieldList = { "Biology", "Marketing", "Commerce", "Software","Finance" };
		String fieldName = fieldList[getRandomNumber(fieldList.length)];
		return fieldName;
	}
	
	
	public static String getFunctionStartWithLetter() {
		
		char []funCharList= {'C','D','E','F','H','L','M','O','P','R','S'};
		char funChar = funCharList[getRandomNumber(funCharList.length)];
		return String.valueOf(funChar);
		
	}
	
	public static String getIndustiesStartWithLetter() {

		char[] industryCharList = { 'A','B','C','E','F','H','I','M','O','P','R','S','T' };
		char industryChar = industryCharList[getRandomNumber(industryCharList.length)];
		return String.valueOf(industryChar);

	}
	
	public static String getCharacter() {
		
		char[] charList = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','O','P','Q','R','S','T' };
		char character = charList[getRandomNumber(charList.length)];
		return String.valueOf(character);
		
	}
	
	
	
	
	
	
	
	
	
	public static int getRandomNumber(int maxNumber) {

		Random random = new Random();
		int randomNum = random.nextInt(maxNumber);
		if (maxNumber != 0 && randomNum == 0) {
			randomNum = 1;
			Log.getLogger().info("Default generated random number : " + randomNum);
		} else {
			Log.getLogger().info("Generated random number : " + randomNum);
		}

		return randomNum;
	}
	
	
	public static int getRandomNumberFromRange(int min, int max) {
		
		Random r = new Random();
		int result = r.nextInt(max-min) + min;
		Log.getLogger().info("Generated random number : " + result);
		return result;
	}
	
	public static int getRandomChoiceNumber(int maxNumber) {
			
		if(maxNumber==0)
		{
			return 1; 
			
		}else {
			return getRandomNumberFromRange(1, maxNumber);
		}
	}
	
	
 public static HashMap<Integer, int[]> getPsychomatricChoiceOrder() {
		
	   HashMap<Integer, int[]> orderChoice = new HashMap<Integer, int[]>();
		
		orderChoice.put(1, new int[]{ 1,3,4,2 });
		orderChoice.put(2, new int[]{ 1,4,2,3 });
		orderChoice.put(3, new int[]{ 4,1,3,2 });
		orderChoice.put(4, new int[]{ 3,4,1,2 });
		orderChoice.put(5, new int[]{ 3,4,1,2 });
		orderChoice.put(6, new int[]{ 2,3,4,1 });
		orderChoice.put(7, new int[]{ 1,3,4,2 });
		orderChoice.put(8, new int[]{ 1,2,4,3 });
		orderChoice.put(9, new int[]{ 3,1,4,2 });
		orderChoice.put(10, new int[]{ 1,3,4,2 });
		orderChoice.put(11, new int[]{ 4,3,1,2 });
		orderChoice.put(12, new int[]{ 1,4,3,2 });
		orderChoice.put(13, new int[]{ 3,1,4,2 });
		orderChoice.put(14, new int[]{ 1,3,4,2 });
		orderChoice.put(15, new int[]{ 4,3,1,2 });
		orderChoice.put(16, new int[]{ 1,3,4,2 });
		
		return orderChoice;
		
		
	}
 
 	
    public static String getDate(String dteFormat) 
    {
		DateFormat dateFormat = new SimpleDateFormat(dteFormat);
		Date date = new Date();
		return dateFormat.format(date);
	}

	public static boolean isEmailValid(String email)
	{
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	

	
}
