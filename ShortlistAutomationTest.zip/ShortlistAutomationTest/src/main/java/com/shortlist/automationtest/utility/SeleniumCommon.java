package com.shortlist.automationtest.utility;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import io.github.bonigarcia.wdm.WebDriverManager;

public class SeleniumCommon {

	public static WebDriver driver = null;

	public static void setUpBrowser(String browserName) {

		try {

			 runTestOnLocalMachine(browserName); 
			
			//runTestOnRemoteMachine();
			

		} catch (Exception ex) {
			Log.getLogger().error("Failed to launch the browser");
			Log.getLogger().error(ex.getMessage());

		}

	}

	public static void closeBrowser() {
		if (driver != null) {
			driver.quit();
		}
	}

	public static WebDriver getDriverInstance() {
		return driver;
	}

	public static void openWebSiteInBrowser() {
		Log.getLogger().info("Test Environment: "+ TestConfiguration.getTestEnvironment());
		String webSiteURL =TestConfiguration.getLoginUrl();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Log.getLogger().info("Implicit wait applied on the driver for 5 seconds");
		driver.get(webSiteURL);

		waitForPageLoad();

		Log.getLogger().info("Checking Agree pop up is available to not");
		Boolean isAgreePopUpDisplayed = isElementExist(By.linkText("AGREE"));
		if (isAgreePopUpDisplayed) {
			SeleniumCommon.clickOnElement(By.linkText("AGREE"));
		}

		Log.getLogger().info("Web application launched: " + driver.getCurrentUrl());
	}

	public static void scrollToElement(WebElement element) {

		if (element != null) {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", element);
		} else {
			Log.getLogger().info("Element not found");
		}
	}

	public static void waitForSecond(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (Exception e) {
			Log.getLogger().info(e.getMessage());
		}
	}

	
	
	public static Boolean isElementExist(By locator,int timeOutInSecond) {
		
		int sleepInMillisecond=5*1000;
		Boolean isExist = true;
		Log.getLogger().info("Searching locator..." + locator);
		long startTime = System.currentTimeMillis();
		try {
			new WebDriverWait(driver, timeOutInSecond, sleepInMillisecond).until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {
			isExist = false;

			Log.getLogger().info("Element not found: " + locator);
			Log.getLogger().error(e.getMessage());
		}
		long endTime = System.currentTimeMillis();
		long totalTime = (endTime - startTime) / 1000;
		if (isExist) {
			Log.getLogger().info("Element found: " + locator + " time: " + totalTime);
		}

		return isExist;
		
	}
	

	public static Boolean isElementExist(By locator) {

		Boolean isExist = true;
		Log.getLogger().info("Searching locator..." + locator);
		long startTime = System.currentTimeMillis();
		try {
			getWebDriverWaitInstance().until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {
			isExist = false;

			Log.getLogger().info("Element not found: " + locator);
			Log.getLogger().error(e.getMessage());
		}
		long endTime = System.currentTimeMillis();
		long totalTime = (endTime - startTime) / 1000;
		if (isExist) {
			Log.getLogger().info("Element found: " + locator + " time: " + totalTime);
		}

		return isExist;
	}
	
	
	public static void waitForURL(String expectedUrl) {
		Boolean isUrlExist = true;
		Log.getLogger().info("Waiting for url to be display.");
		try {
			getWebDriverWaitInstance().until(ExpectedConditions.urlToBe(expectedUrl));
		}catch (Exception e) {
			isUrlExist=false;
			Log.getLogger().info("Error in url to be :"+ e.getMessage());
		}
		
		Log.getLogger().info(expectedUrl +" - "+ isUrlExist);
		
	}
	

	public static WebDriverWait getWebDriverWaitInstance() {
		int timeOutInSeconds=10;
		int sleepInMillisecond=5*1000;
		return new WebDriverWait(driver, timeOutInSeconds, sleepInMillisecond);
	}

	public static void waitForPageLoad() {
		driver.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
	}

	public static void getPageLoadStatus() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		String pageLoadStatus = (String) js.executeScript("return document.readyState");
		Log.getLogger().info("Page Load Status:" + pageLoadStatus);

	}

	public static void runTestOnLocalMachine(String browserName) {
		if (driver == null) {
			
			browserName=TestConfiguration.getBrowser();
			String browserVersion=TestConfiguration.getBrowserVersion();
			
			if (browserName.equalsIgnoreCase("chrome")) {
				
				if(!browserVersion.isBlank())
				{
					Log.getLogger().info("browser version :" + browserVersion);
				    WebDriverManager.chromedriver().version(browserVersion).setup();
				}else {
					Log.getLogger().info("Current browser version");
					WebDriverManager.chromedriver().setup();
				}
				//ChromeOptions options = new ChromeOptions();
				//options.setHeadless(true);
				//driver = new ChromeDriver(options);
				driver = new ChromeDriver();
				Log.getLogger().info("Test will start on chrome browser");

			} else if (browserName.equalsIgnoreCase("firefox")) {
				if(!browserVersion.isBlank())
				{
					Log.getLogger().info("browser version :" + browserVersion);
					WebDriverManager.firefoxdriver().version(browserVersion).setup();
					
				}else {
					Log.getLogger().info("Current browser version");
				    WebDriverManager.firefoxdriver().setup();
				}
				driver = new FirefoxDriver();
				Log.getLogger().info("Test will start on firefox browser");
			} else {

				Log.getLogger().info("browser not found ");
			}

			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		}
	}

	public static void runTestOnRemoteMachine() {
		
		
		Log.getLogger().info("Inside ...remote ");
		String URL="http://192.168.0.3/wd/hub";

		 DesiredCapabilities caps = new DesiredCapabilities();
		 //caps.setCapability("browser", "Chrome");
		 caps.setBrowserName("Chrome");
		//DesiredCapabilities cap = DesiredCapabilities.chrome();
		
		try {
			driver = new RemoteWebDriver(new URL(URL),caps);
		} catch (Exception e) {
			Log.getLogger().info("Error in connecting node: "+ e.getMessage());
		}
	}

	public static void pressEscapeKey() {

		waitForSecond(3);
		Robot robot;
		try {
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {

			e.printStackTrace();
		}

	}

	public static String takeScreenshot() {
        
		SeleniumCommon.waitForSecond(5);
		String screenshotFileName="image"+GenerateTestData.getDate("ddMMyyyyhhmmss");
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File destFile=null;
		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath();
			destFile = new File(reportDirectory + "/screenshots/" + screenshotFileName + ".png");

			FileUtils.copyFile(scrFile, destFile);

		} catch (Exception e) {
			Log.getLogger().error(e.getMessage());
		}
		if(destFile!=null)
		{
			screenshotFileName=destFile.getAbsolutePath();
		}
		return screenshotFileName;

	}
	
	
	public static String takeScreenshotAsBase64() {
		SeleniumCommon.waitForSecond(5);
		String base64String = "";
		try {
			String base64Str = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			base64String="data:image/png;base64," + base64Str;
		} catch (Exception e) {
			Log.getLogger().error(e.getMessage());
		}
		return base64String;
	}
	

	public static boolean clickOnElement(By locator) {
		try {
			isElementExist(locator);
			Log.getLogger().info("Checking element is clickable:" + locator);
			getWebDriverWaitInstance().until(ExpectedConditions.elementToBeClickable(locator));
			Log.getLogger().info("Clicking on element :" + locator);
			WebElement element = driver.findElement(locator);
			element.click();
			Log.getLogger().info("Clicked on element :" + locator);
			return true;
		} catch (Exception e) {
			Log.getLogger().info("Not click on element :" + locator);
			Log.getLogger().error("Error occured while clicking on element:" + e.getMessage());
			return false;
		}
	}

	public static void sendInput(By locator, String input) {

		isElementExist(locator);
		Log.getLogger().info("Entering data to element : " + locator);
		driver.findElement(locator).sendKeys(input);
		Log.getLogger().info("Data entered : " + locator + " " + input);
	}

	public static void scrollVertical() {

		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Log.getLogger().info("Scrolled vertically down page");
	}
	
	
	
	public void getSystemInfo() {
      
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = cap.getBrowserName().toLowerCase();
		String browserVersion = cap.getVersion();
		String sysUserName = System.getProperty("user.name");
		String javaVersion = System.getProperty("java.version");
		String ipAddress = "";

		try {
			ipAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		Log.getLogger().info("user.name: " + sysUserName);
		Log.getLogger().info("java.version: " + javaVersion);
		Log.getLogger().info("BrowserName: " + browserName);
		Log.getLogger().info("Browser version: " + browserVersion);
		Log.getLogger().info("IP Address: " + ipAddress);
		
	
	}

	public static List<String> getBrowserConsoleLog() {

		waitForSecond(10);
		List<String> list= new ArrayList<String>();
       
		try {
			LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
			Log.getLogger().info("Browser Console Log");
			Log.getLogger().info("Total console Log error: " + logEntries.getAll().size());

			for (LogEntry entry : logEntries) {
				String logType = entry.getLevel().toString();
				if (logType.equalsIgnoreCase("SEVERE")) {
					Log.getLogger().info(new Date(entry.getTimestamp()) + " " + entry.toString() + " \n");
					Log.getLogger().info("entry.getLevel(): " + entry.getLevel());
					Log.getLogger().info("entry.getMessage(): " + entry.getMessage());
					Log.getLogger().info("entry.toString(): " + entry.toString());
					list.add(entry.getMessage());
				}
			}
		} catch (Exception e) {
			Log.getLogger().info("Error Occured while capturing browser console log");
			Log.getLogger().info("Error:" + e.getMessage());
		}
		
		return list;
	}
	
	
	public void clearConsoleErrors()
	{
	    JavascriptExecutor js = (JavascriptExecutor)driver;
	    String script = "console.clear();";
	    js.executeScript(script);
	    //driver.manage().logs().get(LogType.BROWSER).filter(Level.ALL);
	}
	
	
	
	public static String checkAnyWarningMessage() {

		// Check any warning message appears on page
		String warningMessage="";
		if (driver.getPageSource()
				.contains("//simple-snack-bar[@class=\"mat-simple-snackbar ng-star-inserted\"]/span")) {

			By warmingPup = By.xpath("//simple-snack-bar[@class=\"mat-simple-snackbar ng-star-inserted\"]/span");
			Boolean isWarningPopupExit = SeleniumCommon.isElementExist(warmingPup);
			if (isWarningPopupExit) {
				warningMessage = driver.findElement(warmingPup).getText();
				Log.getLogger().info("----> Warning Message :" + warningMessage);
				
			}
		}else {
			
			Log.getLogger().info("Warning message not found");
		}
		
		return warningMessage;
	}
	
	
	
	public static Boolean isPageLoaded() {
		
		Boolean isPageLoadingIssueOccured=false;
		
		if(driver.getPageSource().contains("mat-spinner mat-progress-spinner mat-primary mat-progress-spinner-indeterminate-animation"))
		{
			By loaderLocator=By.xpath("//mat-spinner[@role=\"progressbar\"]");
			Boolean isLoaderShowingOnPage=SeleniumCommon.isElementExist(loaderLocator);
			if(isLoaderShowingOnPage) {
				Log.getLogger().info("Page is not loaded, please check screenshot");
				isPageLoadingIssueOccured=true;
			}else {
				Log.getLogger().info("No page loading issue found");
			}
		}
		
		return isPageLoadingIssueOccured;
	}
	
	
	
	
	

}
