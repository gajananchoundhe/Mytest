package com.shortlist.automationtest.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {

	static Connection connection=null;
	static String QA_SHORTLIST_DB_URL="jdbc:mysql://stagingsep.c98kszjbfxlr.ap-southeast-1.rds.amazonaws.com:3306/?user=gajanan&password=Admin@123";
	static String QA_Chatbot_DB_URL="jdbc:mysql://stagingchatbot.c98kszjbfxlr.ap-southeast-1.rds.amazonaws.com:3306/?user=gajanan&password=Admin@123";
	
	public static List<String> getJobAssessementList(int jobId) {
		
			
		List<String> list=new ArrayList<String>();  
		
		String getAssessementListQuery = "SELECT * FROM shortlist_prod.job_assessment_rel where jobId=" + jobId + ";";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getAssessementListQuery);

			while (rs.next()) {
				System.out.println("Assessment Name: " + rs.getString("assessmentName"));
				list.add(rs.getString("assessmentName"));
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}
		
		return list;

	}
	
	
	
	
	
	public static ResultSet getQueryResult(String dbURL, String query) {

		ResultSet result = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(dbURL);
			Statement stmt = connection.createStatement();
			result = stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;

	}

	public static void closeConnection() {
		try {
			if (connection != null)
				connection.close();
			System.out.println("Connection closed !!");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
	
	
	
}
