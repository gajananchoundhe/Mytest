package com.shortlist.automationtest.utility;

import java.io.File;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestReport  {
	
	static ExtentTest test;
	static ExtentReports report;
	
	
	public static void initReport() {
		
		String extConfigFilePath=System.getProperty("user.dir")+"\\TestCofiguration\\extent-config.xml";
		Log.getLogger().info("Config File :"+ extConfigFilePath);
		String reportName=TestConfiguration.getAutomationTestReportName();
		report = new ExtentReports(System.getProperty("user.dir") + "\\"+reportName+".html", true);
		report.loadConfig(new File(extConfigFilePath));
		String env=TestConfiguration.getTestEnvironment();
		report.addSystemInfo("Environment", env.toUpperCase());
		report.addSystemInfo("Module Name", "Candidate Portal");
		report.addSystemInfo("Test Category", "Sanity Testing");
		
	}
	
	public static void startTest(String testTitle, String testSummary) {
		
		test = report.startTest(testTitle, testSummary);
	}
	
	public static void startTest(String testTitle) {

		test = report.startTest(testTitle);
	}

	public static void endTest() {

		report.endTest(test);
	}

	

	public void assignTestCategory(String testCategoryName) {

		test.assignCategory(testCategoryName);
	}

	public static void testPass(String stepDescription) {

		test.log(LogStatus.PASS, stepDescription);
	}
    
		
	
	public static void testPassWithScreenshot(String stepDescription) {

		String imageFilePath = getScreenshotImagePath();
		test.log(LogStatus.PASS, stepDescription);
		test.log(LogStatus.PASS, stepDescription, imageFilePath);
	}

	public static void testFail(String stepDescription) {
		String imageFilePath = getScreenshotImagePath();
		test.log(LogStatus.FAIL, stepDescription);
		test.log(LogStatus.FAIL, stepDescription, imageFilePath);
	}

	public static void testInfo(String stepDescription) {

		test.log(LogStatus.INFO, stepDescription);
	}

	public static void testSkip(String stepDescription) {
		String imageFilePath = getScreenshotImagePath();
		test.log(LogStatus.SKIP, stepDescription);
		test.log(LogStatus.SKIP, stepDescription, imageFilePath);
	}

	public static void testWarn(String stepDescription) {

		test.log(LogStatus.WARNING, stepDescription);
	}

	public static void testConsoleLog(String message) {

		String consoleLogMessage = "<b><span style=\"color: #D8000C;background-color: #FFD2D2;\"> Console Log- </span><b/> "
				+ message;
		test.log(LogStatus.INFO, "HTML", consoleLogMessage);
	}

	public static String getScreenshotImagePath() {

		String screenshotOutType = "BASE64";
		screenshotOutType = TestConfiguration.getGetScreenshotOutputType();

		String outputOfScreenshot = "";
		if (screenshotOutType.equalsIgnoreCase("BASE64")) {
			outputOfScreenshot = test.addBase64ScreenShot(SeleniumCommon.takeScreenshotAsBase64());
		} else {
			outputOfScreenshot = test.addScreenCapture(SeleniumCommon.takeScreenshot());
		}

		return outputOfScreenshot;
	}

	public static void endReport() {

		report.flush(); // call this method every after test
	}

	
	
		
	
	
	
	
	}
