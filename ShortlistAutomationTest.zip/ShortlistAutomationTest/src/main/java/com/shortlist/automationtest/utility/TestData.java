package com.shortlist.automationtest.utility;

public class TestData {

	public static String getInputTestData(String question, String inputType) {

		String inputData="";
		Log.getLogger().info("Inside test- question: "+ question);
		
		if (!question.isBlank()) {

			if (inputType.equalsIgnoreCase("API_CALL")) {

				if ("Thanks, what city do you currently live in?".equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getCity();
				} else if ("Would you consider jobs in any other cities? Enter all that apply:"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getCity();
				} else if ("From which institution did/will you receive this degree or credential?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getInstituteName();
				} else if ("And from which institution did you receive this postgraduate degree?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getInstituteName();
				} else if ("From which institution did you receive this undergraduate degree?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getInstituteName();
				} else if ("In which of the following industries would you be interested in developing your career?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getIndustiesStartWithLetter();
				} else if ("Thanks! Now we'd like to get to know a bit more about your professional background. What industries do you have the most experience in? (Choose up to three)"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getIndustiesStartWithLetter();
				} else if ("Awesome, what functions do you have the most experience in? (Again, choose up to three)"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getFunctionStartWithLetter();
				} else if ("In which of the following functions would you be interested in developing your career?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getFunctionStartWithLetter();
				}

			}

			if (inputType.equalsIgnoreCase("INPUT_TEXT")) {
				if ("Let's get started! What's your full name?".equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getName();
				} else if ("Cool - and your job title there?".equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getJobTitle();
				} else if ("And what was your concentration (major) at this institution?".equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getFieldName();
				} else if ("Got it. What’s the name of your current or most recent employer?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getEmployerName();
				} else if ("Would you like to share your LinkedIn or other online profile? (Please paste the link below.)"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getLinkedinUrl();
				} else if ("Let's move on to your work experience - how many years of professional experience do you have?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getExperience();
				} else if ("You're doing great. Now let’s talk about compensation. What's your current salary?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getActualSalary();
				} else if ("And what is your expected gross salary (salary before any deductions) for your next position?"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getExpectedSalary();
				} else if ("We know you might still be in university, but do you have any work experience (part-time, internship, personal projects, or fellowship?)"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getJobType();
				} else if ("Would you like to upload your resume?".equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getResumeUrl();
				} else if ("Would you like to upload a photo? (It will help bring your application to life!)"
						.equalsIgnoreCase(question)) {
					inputData = GenerateTestData.getPhotoUrl();
				}

			}
		}
		
		Log.getLogger().info("inputData: "+ inputData);

		return inputData;

	}
	
	
	
	public static String getInputDatatest(InputField inputField) {
		
		String inputData="";
		
		switch (inputField) {
		case CITY:
			inputData=GenerateTestData.getCity();
			break;
		case INSTITUTION:
			inputData=GenerateTestData.getInstituteName();
			break;
		case INDUSTRIES:
			inputData=GenerateTestData.getIndustiesStartWithLetter();
			break;
		case FUNCTIONS:
			inputData=GenerateTestData.getFunctionStartWithLetter();
			break;
		case JOBTITLE:
			inputData=GenerateTestData.getJobTitle();
			break;
		case NAME:
			inputData=GenerateTestData.getName();
			break;
		case FIELDNAME:
			inputData=GenerateTestData.getFieldName();
			break;
		case EMPLOYER:
			inputData=GenerateTestData.getEmployerName();
			break;
		case LINKEDIN:
			inputData=GenerateTestData.getLinkedinUrl();
			break;
		case EXPERIENCE:
			inputData=GenerateTestData.getExperience();
			break;
		case CURRENT_SALARY:
			inputData=GenerateTestData.getActualSalary();
			break;
		case EXPECTED_SALARY:
			inputData=GenerateTestData.getExpectedSalary();
			break;
		case JOBTYPE:
			inputData=GenerateTestData.getJobType();
			break;
		case RESUME:
			inputData=GenerateTestData.getResumeUrl();
			break;
		case PHOTO:
			inputData=GenerateTestData.getPhotoUrl();
			break;

		default:
			break;
		}
		
		return inputData;
	}
	
	
	public enum InputField {
		CITY,INSTITUTION,INDUSTRIES,FUNCTIONS,JOBTITLE,NAME,FIELDNAME,EMPLOYER,LINKEDIN,EXPERIENCE,CURRENT_SALARY,EXPECTED_SALARY,JOBTYPE,RESUME,PHOTO,NONE
	}
	
	
	
	
	

	
	
}
