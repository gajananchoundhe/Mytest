package com.shortlist.automationtest.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class TestConfiguration {

    static Properties prop;

    public static void loadTestConfigDataInObject() {

    	InputStream file =null;
		try{

			String filePath=System.getProperty("user.dir")+"\\TestCofiguration\\config.properties";
			System.out.println("Configuration file path :"+ filePath);
			file = new FileInputStream(filePath);
            prop = new Properties();
            prop.load(file);
            System.out.println("Configuration file loaded");
            file.close();

        } catch (Exception ex) {
            System.out.println("Exception: "+ ex.getMessage());
        }

    }


    public static String getTestEnvironment() {	
    	return prop.getProperty("test.execution.env");
 	}
    
    public static String getBrowser() {	
    	return prop.getProperty("browser");
 	}
    
    public static String getBrowserVersion() {	
    	
    	return prop.getProperty("browser.version."+ getBrowser());
 	}
    
    
    public static String getSignupEmail() {	
    	return prop.getProperty(getTestEnvironment()+".signup.email");
 	}
    
    public static String getSignupPassword() {	
    	return prop.getProperty("signup.password");
 	}
    
    public static String getJobId() {	
    	return prop.getProperty(getTestEnvironment()+".jobId");
 	}
    
    public static String getCandidateLoginUsername() {	
    	return prop.getProperty(getTestEnvironment()+".candidate.login.username");
 	}
    
    public static String getCandidateLoginPassword() {	
    	return prop.getProperty(getTestEnvironment()+".candidate.login.password");
 	}
    
    public static String getWebsiteUrl() {	
    	return prop.getProperty(getTestEnvironment()+".website.url");
 	}
    
    public static String getLoginUrl() {	
    	return prop.getProperty(getTestEnvironment()+".login.url");
 	}
    
    public static String getTestJobId() {	
    	return prop.getProperty(getTestEnvironment()+".test.jobId");
 	}
    
    public static String getGetScreenshotOutputType() {	
    	return prop.getProperty("screenshot.outputType");
 	}
    
    public static String getAutomationTestReportName() {	
    	return prop.getProperty("automation.test.report.name");
 	}
    
    public static String getTestExecuteOrder() {	
    	return prop.getProperty("test.execute.order");
 	}
    
    
    
    public static String getPropertyValue(String key) {
	 
    	return prop.getProperty(key);
	}
    
    public static void putValue(String key, String value) {
    	prop.put(key, value);
	}
    
    public static Boolean isKeyExistInProperty(String key) {
		
    	if(prop.containsKey(key))
    	{
    		return true;
    	}
    	else {
    		return false;
    	}
	}
    
    
    
    }
