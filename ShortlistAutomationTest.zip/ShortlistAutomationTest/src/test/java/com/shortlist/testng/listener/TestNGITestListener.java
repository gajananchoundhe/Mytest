package com.shortlist.testng.listener;

import java.util.List;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestReport;

public class TestNGITestListener implements ITestListener {

	
	public void onTestFailure(ITestResult result) {

		if (!result.isSuccess()) {
			
			TestReport.testFail(result.getThrowable().getMessage());
			
			List<String> list= SeleniumCommon.getBrowserConsoleLog();
			if(!list.isEmpty())
			{  
				for (String msg : list) {
					TestReport.testConsoleLog(msg);
			    }
			}
			
			String warningMessage=SeleniumCommon.checkAnyWarningMessage();
			
			if(!warningMessage.isBlank())
			{
				TestReport.testConsoleLog(warningMessage);
			}
			
			TestReport.endTest();
			
			GenerateTestData.testFailed++;
		}

	}
	
	public void onTestSuccess(ITestResult result) {
		if (result.isSuccess()) {
			
			TestReport.testPassWithScreenshot(result.getMethod().getMethodName());
			List<String> list= SeleniumCommon.getBrowserConsoleLog();
			if(!list.isEmpty())
			{  
				for (String msg : list) {
					TestReport.testConsoleLog(msg);
			    }
			}
			String warningMessage=SeleniumCommon.checkAnyWarningMessage();
			
			if(!warningMessage.isBlank())
			{
				TestReport.testConsoleLog(warningMessage);
			}
			TestReport.endTest();
			
			GenerateTestData.testPassed++;
		}

	}
	
	public void onTestSkipped(ITestResult result) {
		
		
		TestReport.testSkip(result.getMethod().getMethodName() + " - "+ result.getThrowable().getMessage());
		
		List<String> list= SeleniumCommon.getBrowserConsoleLog();
		if(!list.isEmpty())
		{  
			for (String msg : list) {
				TestReport.testInfo("Console Log: "+msg);
		    }
		}
		TestReport.endTest();
		
		GenerateTestData.testSkipped++;

	}
	
	
	public void onFinish(ITestContext result) {
		//Reporter.log("Test is finished:" + result.getName());
		

	}

	public void onStart(ITestContext result) {
		//Log.getLogger().info("Test is started:" + result.getName());

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	public void onTestStart(ITestResult result) {
		//Reporter.log(ITestResult.class.getSimpleName() + " Test started");

	}

	

}
