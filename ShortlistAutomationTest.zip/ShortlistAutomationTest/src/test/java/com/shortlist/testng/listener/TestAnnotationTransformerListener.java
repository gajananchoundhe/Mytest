package com.shortlist.testng.listener;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import com.shortlist.automationtest.utility.TestConfiguration;

public class TestAnnotationTransformerListener implements IAnnotationTransformer {

	
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {

		/*
		System.out.println("Jenkin Param browser: "+ System.getProperty("browser_") );
		System.out.println("Jenkin Param Env: "+ System.getProperty("test.execution.env_") );
		System.out.println("Jenkin Param Order: "+ System.getProperty("test.execute.order_") );
		System.out.println("Run Test On: "+ System.getProperty("remoteRun") );
		*/
		
		
		TestConfiguration.loadTestConfigDataInObject();
		String testExecutionOrder = TestConfiguration.getTestExecuteOrder();
		
		char entry = '$';
		if (testExecutionOrder.length() == 1) {
			entry = testExecutionOrder.charAt(0);
		}
		char step = '0';
		if (testExecutionOrder.length() == 2) {
			step = testExecutionOrder.charAt(1);
		}

		if (entry == '$') {
			if (testMethod.getName().equals("verifySignUpTest")) {
				System.out.println("verifySignUpTest " + testMethod.getName());
				annotation.setEnabled(false);
			}

		} else if (entry == '#') {

			if (testMethod.getName().equals("verifyLogin")) {
				System.out.println("verifyLogin " + testMethod.getName());
				annotation.setEnabled(false);
			}
		}

		if (step == 0) {

			if (step == '1') {
				if (testMethod.getName().equals("verifyCharlieAssessment")) {
					System.out.println("verifyCharlieAssessment " + testMethod.getName());
					annotation.setEnabled(false);
				}

				if (testMethod.getName().equals("verifyVoiceTest")) {
					System.out.println("verifyVoiceTest " + testMethod.getName());
					annotation.setEnabled(false);
				}

				if (testMethod.getName().equals("verifyPsychometricTest")) {
					System.out.println("verifyPsychometricTest " + testMethod.getName());
					annotation.setEnabled(false);
				}
			}

			if (step == '2') {

				if (testMethod.getName().equals("verifyVoiceTest")) {
					System.out.println("Voice " + testMethod.getName());
					annotation.setEnabled(false);
				}

				if (testMethod.getName().equals("verifyPsychometricTest")) {
					System.out.println("Psychometric " + testMethod.getName());
					annotation.setEnabled(false);
				}
			}

			if (step == '3') {
				if (testMethod.getName().equals("verifyPsychometricTest")) {
					System.out.println("Psychometric " + testMethod.getName());
					annotation.setEnabled(false);
				}
			}

		}else {
			
			if (testMethod.getName().equals("verifyApplyJobOnJDpage")) {
				System.out.println("verifyApplyJobOnJDpage " + testMethod.getName());
				annotation.setEnabled(false);
			}
			
			if (testMethod.getName().equals("verifyChatbot")) {
				System.out.println("verifyChatbot " + testMethod.getName());
				annotation.setEnabled(false);
			}
			
			if (testMethod.getName().equals("verifyCharlieAssessment")) {
				System.out.println("verifyCharlieAssessment " + testMethod.getName());
				annotation.setEnabled(false);
			}

			if (testMethod.getName().equals("verifyVoiceTest")) {
				System.out.println("verifyVoiceTest " + testMethod.getName());
				annotation.setEnabled(false);
			}

			if (testMethod.getName().equals("verifyPsychometricTest")) {
				System.out.println("verifyPsychometricTest " + testMethod.getName());
				annotation.setEnabled(false);
			}
			
		}
		
		
		

	}

}
