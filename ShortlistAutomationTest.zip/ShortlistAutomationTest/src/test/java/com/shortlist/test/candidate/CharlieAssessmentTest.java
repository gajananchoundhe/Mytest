package com.shortlist.test.candidate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shortlist.pages.candidate.CharlieAssessmentPage;

public class CharlieAssessmentTest {

    CharlieAssessmentPage charlie;

    @BeforeClass
    public void beforeClass() {
    	charlie = new CharlieAssessmentPage();

    }
      

    @Test(priority = 5) 
    public void verifyCharlieAssessment()
    {
    	charlie.startCharlieAssessment();
    }

}
