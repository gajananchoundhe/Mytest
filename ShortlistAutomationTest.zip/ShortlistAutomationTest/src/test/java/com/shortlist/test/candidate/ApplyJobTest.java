package com.shortlist.test.candidate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shortlist.pages.candidate.JobsPage;

public class ApplyJobTest {

	JobsPage jobspage;
	
	@BeforeClass
    public void beforeClass() {
		jobspage = new JobsPage();

    }
	
	@Test(priority = 3) 
    public void verifyApplyJobOnJDpage()
    {
		jobspage.applyJob();
    }
	
	
}
