package com.shortlist.test.candidate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shortlist.pages.candidate.PsychometricPage;

public class PsychometricTest {

	PsychometricPage test;

	@BeforeClass
	public void beforeClass() {
		test = new PsychometricPage();

	}

	@Test(priority = 7)
	public void verifyPsychometricTest() {
		test.startPsychometricTest();
	}

}
