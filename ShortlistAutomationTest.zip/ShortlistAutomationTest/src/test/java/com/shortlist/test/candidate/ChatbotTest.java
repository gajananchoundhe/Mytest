package com.shortlist.test.candidate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shortlist.pages.candidate.ChatbotPage;

public class ChatbotTest {

    ChatbotPage job;

    @BeforeClass
    public void beforeClass()
    {
        job = new ChatbotPage();

    }

    @Test(priority = 4)
    public void verifyChatbot()
    {
    	job.startChatbot();
    }
    
    
    
}
