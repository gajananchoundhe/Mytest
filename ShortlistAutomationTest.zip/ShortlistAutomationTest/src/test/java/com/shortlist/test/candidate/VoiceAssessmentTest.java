package com.shortlist.test.candidate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shortlist.pages.candidate.VoiceAssessmentPage;

public class VoiceAssessmentTest {

	 VoiceAssessmentPage voiceTest;

	    @BeforeClass
	    public void beforeClass() {
	    	voiceTest = new VoiceAssessmentPage();

	    }
	    
	    
	    @Test(priority = 6)
		public void verifyVoiceTest() {
	    	voiceTest.startVoiceAssessment();
		}
}
