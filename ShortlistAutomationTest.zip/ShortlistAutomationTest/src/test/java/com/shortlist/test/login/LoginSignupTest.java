package com.shortlist.test.login;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.shortlist.automationtest.utility.EmailReport;
import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumCommon;
import com.shortlist.automationtest.utility.TestConfiguration;
import com.shortlist.automationtest.utility.TestReport;
import com.shortlist.pages.login.LoginSignUpPage;

public class LoginSignupTest {

    LoginSignUpPage candidatePortal;

    @BeforeClass
    public void beforeClass() {
        candidatePortal = new LoginSignUpPage();

    }

    @BeforeSuite
    @Parameters({"browserName"})
    public void setup(String browserName) {
    	
    	Log.invokeLogger(); 
    	TestConfiguration.loadTestConfigDataInObject();
    	
    	String env=System.getProperty("TestEnvironment").toLowerCase();
    	TestConfiguration.putValue("test.execution.env",env);
    	TestConfiguration.putValue("browser",System.getProperty("Browser").toLowerCase());
    	TestConfiguration.putValue(env+".jobId",System.getProperty("JobID"));
    	
		System.out.println("Jenkin Param TestEnvironment: "+ System.getProperty("TestEnvironment") );
		System.out.println("Jenkin Param Browser: "+ System.getProperty("Browser") );
		System.out.println("Jenkin Param JobID: "+ System.getProperty("JobID") );
		//System.out.println("Run Test TestType: "+ System.getProperty("TestType") );
		
    
    	TestReport.initReport();
        SeleniumCommon.setUpBrowser(browserName);
        SeleniumCommon.openWebSiteInBrowser();
        
        GenerateTestData.startTestTime=GenerateTestData.getDate("dd/MM/yy HH:mm:ss");
    }

    @Test(priority = 1,groups={"SignUp"})
    public void verifySignUpTest()
    {
        candidatePortal.fillSignUpFormAndSubmit();
    }


    
    @Test(priority = 2,groups={"SignUp"}, description="Verify user is able to login with valid credential", enabled = false)
    public void verifyLogin() {
        candidatePortal.login();
    }
    
   


    @AfterSuite
    public void closeTest()
    {
        //SeleniumCommon.closeBrowser();
    	TestReport.endReport();
    	GenerateTestData.endTestTime=GenerateTestData.getDate("dd/MM/yy HH:mm:ss");
    	String isEmailReportSent=TestConfiguration.getPropertyValue("report.email.send");
    	if(isEmailReportSent.equalsIgnoreCase("yes"))
    	{
    		EmailReport.send();
    	}
    	
    }
    
    
    /*
    @BeforeMethod
    public void beforeMethod(Method method) {
        Test test = method.getAnnotation(Test.class);
        Log.getLogger().info("Test description:  " + test.description());
    }
    */
    
    
    @AfterMethod
    public void tearDown(ITestResult result) {
      
       if (result.getStatus() == ITestResult.SUCCESS) {
    	   
    	   if(SeleniumCommon.isPageLoaded())
    	   {
    		   Assert.fail(result.getName() +" - Page not loaded, loader showing on page");
    	   }
    	  
           
       }    
    }

}
