package ConcurrentTest;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;

public class ParallelMethodTest {
  
	
	@BeforeSuite
    public void beforeSuite() {
        long id = Thread.currentThread().getId();
        System.out.println("Suite before test-method. Thread id is: " + id);
    }
 
    @Test
    public void testMethodsOne() {
        long id = Thread.currentThread().getId();
        System.out.println("Simple test-method One. Thread id is: " + id);
    }
 
    @Test
    public void testMethodsTwo() {
        long id = Thread.currentThread().getId();
        System.out.println("Simple test-method Two. Thread id is: " + id);
    }
    
    @Test
    public void testMethodsThree() {
        long id = Thread.currentThread().getId();
        System.out.println("Simple test-method Three. Thread id is: " + id);
    }
 
    @Test
    public void testMethodsFour() {
        long id = Thread.currentThread().getId();
        System.out.println("Simple test-method four. Thread id is: " + id);
    }
 
    @AfterSuite
    public void afterSuite() {
        long id = Thread.currentThread().getId();
        System.out.println("suite after test-method. Thread id is: " + id);
    }
  
  
  

}
