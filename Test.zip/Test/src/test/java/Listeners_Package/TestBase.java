package Listeners_Package;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;


import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	
	public static WebDriver driver;
    
	@BeforeTest
	public void setUp(){
		
    	WebDriverManager.chromedriver().setup();
    	driver = new ChromeDriver();
		
		
		 //DesiredCapabilities caps = DesiredCapabilities.chrome(); LoggingPreferences
		 //log = new LoggingPreferences(); log.enable(LogType.PERFORMANCE,Level.ALL);
		 //caps.setCapability(CapabilityType.LOGGING_PREFS, log);
		
		  
    	/*
		try {
			URL url=new URL("http://10.137.249.210:4444/wd/hub");
			Capabilities capabilities=DesiredCapabilities.chrome();
	    	driver = new RemoteWebDriver(url,capabilities);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
    	       
    	 
    	

    	}
	
	
}
