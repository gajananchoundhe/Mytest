package Listeners_Package;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class TestLogin2 extends TestBase {

	@Test
	public void testBrowserLog() throws InterruptedException {

		driver.get("https://qa.shortlist.net/webportal/#/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.name("userName")).sendKeys("gajanan@shortlist.net");
		driver.findElement(By.name("password")).sendKeys("Admin@123");
		driver.findElement(By.xpath("//span[text()=\" LOG IN \"]")).click();
		Assert.assertEquals("Loggin done", "Login not done");
		
		
	}

	
	@AfterSuite
	public void close() {
		driver.quit();
	}

}


