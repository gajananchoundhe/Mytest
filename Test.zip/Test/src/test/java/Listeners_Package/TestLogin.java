package Listeners_Package;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.BuildInfo;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestLogin extends TestBase {

	static ExtentTest test;
	static ExtentReports report;

	@Test(enabled = false)
	public void testEventListener() throws InterruptedException {
		driver.get("http://automationpractice.com/index.php");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 200);
		wait.until(ExpectedConditions
				.visibilityOf(driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a"))));
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();

		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("testCode");
		driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("testpass");
		driver.findElement(By.xpath("//*[@id='SubmitLogin122']")).click();
	}

	@Test(enabled = false)
	public void openWebsite() {

		report = new ExtentReports(System.getProperty("user.dir") + "\\ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
		test.log(LogStatus.PASS, "Navigated to the specified URL");
		test.log(LogStatus.FAIL, "Test Failed");

		report.endTest(test);
		report.flush();

	}

	@Test
	public void testBrowserLog() throws InterruptedException {

		driver.get("https://qa.shortlist.net/opsportal/#!/login");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// WebDriverWait wait = new WebDriverWait(driver, 120);
		// wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a"))));
		// driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();

		driver.findElement(By.id("input_0")).sendKeys("gajanan@shortlist.net");
		driver.findElement(By.id("input_1")).sendKeys("Admin@123");
		driver.findElement(By.xpath("//span[text()=\"LOGIN\"]")).click();

		 printSystemInfo();
		//getBrowserConsoleLog();

		// driver.findElement(By.xpath("//span[text()=\"LOGIN\"]")).click();

		// getBrowserConsoleLog();

	}

	public void getBrowserConsoleLog() {

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
		System.out.println("Browser Console Log");
		
		System.out.println("Total console Log error: "+ logEntries.getAll().size());
		
		for (LogEntry entry : logEntries) {
			System.out.println(new Date(entry.getTimestamp()) + " " + entry.toString() + " \n");

			 System.out.println("entry.getLevel(): "+ entry.getLevel());
			 System.out.println("entry.getMessage(): "+ entry.getMessage()); //
			System.out.println("entry.toString(): " + entry.toString());
		}

		

	}

	public void printSystemInfo() {

		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = cap.getBrowserName().toLowerCase();
		String browserVersion = cap.getVersion().toString();
		String sysUserName=System.getProperty("user.name");
		String javaVersion=System.getProperty("java.version");
		String ipAddress="";
		
		System.out.println("user.name: " + sysUserName);
		System.out.println("java.version: " + javaVersion);
		System.out.println("BrowserName:" + browserName);
		System.out.println("Browser version: " + browserVersion);

		try {
			ipAddress=InetAddress.getLocalHost().getHostAddress();
			System.out.println("IP Address: " + ipAddress);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	@AfterSuite
	public void close() {
		driver.quit();
	}

}


