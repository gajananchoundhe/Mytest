package Listeners_Package;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ListenerInSelenium extends TestBase implements ITestListener {

	static ExtentTest test;
	static ExtentReports report;

	public void onFinish(ITestContext arg0) {
		Reporter.log("Test is finished:" + arg0.getName());

	}

	public void onStart(ITestContext arg0) {
		Reporter.log("Test is started:" + arg0.getName());

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestFailure(ITestResult arg0) {

		if (!arg0.isSuccess()) {

			

			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("ddMMyyyyhhmmss");

			String methodName = arg0.getName();

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/test/java/";
				File destFile = new File(reportDirectory + "/failure_screenshots/" + methodName + "_"
						+ formater.format(calendar.getTime()) + ".png");

				FileUtils.copyFile(scrFile, destFile);

				Reporter.log(" <a href=" + destFile.getAbsolutePath() + "> <img src=" + destFile.getAbsolutePath()
						+ "height=100 width=100> </a> ");

				String extConfig = "C:\\Shortlist\\workspace\\Test\\src\\main\\resources\\configFile\\extent-config.xml";
				System.out.println("Path: " + extConfig);
				report = new ExtentReports(System.getProperty("user.dir") + "\\ExtentReportResults.html", true);
				report.loadConfig(new File(extConfig));
				report.addSystemInfo("Selenium Version", "2.46");
				report.addSystemInfo("Environment", "Prod");

				
				test = report.startTest("Shortlist- Candidate Portal", "Login description");
				test.assignCategory("Regression Testing");

				test.log(LogStatus.PASS, "Navigated to the specified URL");
				String file = test.addScreenCapture(destFile.getAbsolutePath());
				test.log(LogStatus.FAIL, arg0.getMethod().getMethodName(), file);
				test.log(LogStatus.INFO, "Snapshot below: " + file);
				test.log(LogStatus.FAIL, arg0.getMethod().getMethodName(), arg0.getThrowable().getMessage());

				// test.log(LogStatus.FAIL, "Test Failed");

				report.endTest(test);
				report.flush();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestStart(ITestResult arg0) {
		Reporter.log(ITestResult.class.getSimpleName() + " Test started");

	}

	public void onTestSuccess(ITestResult arg0) {
		if (arg0.isSuccess()) {
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

			String methodName = arg0.getName();

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/test/java/";
				File destFile = new File(reportDirectory + "/Test_sucess/" + methodName + "_"
						+ formater.format(calendar.getTime()) + ".png");

				FileUtils.copyFile(scrFile, destFile);

				Reporter.log("<a href=" + destFile.getAbsolutePath() + "> <img src=" + destFile.getAbsolutePath()
						+ "height=100 width=100 > </a> ");

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
