package Listeners_Package;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestReport extends TestBase {
	
	static ExtentTest test;
	static ExtentReports report;
	
	
	public static void initReport() {
		
		String extConfig = "C:\\Shortlist\\workspace\\Test\\src\\main\\resources\\configFile\\extent-config.xml";
		System.out.println("Path: " + extConfig);
		report = new ExtentReports(System.getProperty("user.dir") + "\\ExtentReportResults2.html", true);
		report.loadConfig(new File(extConfig));
		report.addSystemInfo("Selenium Version", "2.46");
		report.addSystemInfo("Environment", "Prod");
	}
	
	
	public static void startTest(String testName) {
		
		test = report.startTest(testName);
		//test = report.startTest("Login description");
	}
	
	  public static void endTest() {
			
		report.endTest(test);
	 }

	
	 public static void startTest(String testName, String testDescription) {
		
		test = report.startTest(testName,testDescription);
		//test = report.startTest("Shortlist- Candidate Portal", "Login description");
	}
	 
	public void assignCategoryToTest(String testCategoryName) {
		
		test.assignCategory(testCategoryName);
		//test.assignCategory("Regression Testing");
	} 
	
	public static void testPass(String stepName) {
		
		test.log(LogStatus.PASS, stepName);
	}
	
    public static void testPassWithScreenshot(String stepName) {
    	
    	String filePath = test.addScreenCapture(takeScreenshot());
		test.log(LogStatus.PASS, stepName, filePath);
	}
	
	public static void testFail(String stepName) {
		String filePath = test.addScreenCapture(takeScreenshot());
		test.log(LogStatus.FAIL, stepName, filePath);	
	}
	
	public static void testInfo(String stepName) {
		
		test.log(LogStatus.INFO, stepName);
	}
	
	public static String takeScreenshot() {
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("ddMMyyyyhhmmss");

		String methodName = "screenshot";
		String filePath="";

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/test/java/";
			File destFile = new File(reportDirectory + "/failure_screenshots/" + methodName + "_"
					+ formater.format(calendar.getTime()) + ".png");

			FileUtils.copyFile(scrFile, destFile);
			filePath=destFile.getAbsolutePath();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return filePath;
		
	}
	
	
	
	
	
	
	
	}
