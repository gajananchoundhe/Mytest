package package3;

public class config {

	public static boolean testMethodRun=false;
}
