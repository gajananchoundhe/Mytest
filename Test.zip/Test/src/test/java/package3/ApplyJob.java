package package3;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.ITestAnnotation;

public class ApplyJob {
  
	
	@BeforeSuite
	  public void beforeSuite() {
		  
		  System.out.println("This before suite test");
	  }
	
	@Test(priority=1)
	  public void ChatBotTest() {
		  
		  System.out.println("This is chatbot test");
		  		  
	  }
	
	@Test(priority=2)
	  public void assessmentTest() {
		  
		  System.out.println("This is assessment test");
		  
	  }
	
	
  @Test(priority=3)
  public void Charlie() {
	  
	  System.out.println("This is charlie test");
	  
  }
  
  
  @Test(priority=4)
  public void Pscychilogi() {
	  
	  System.out.println("This is sycho test");
  }
  
  

}
