package package3;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;
 
public class TestAnnotationTransformerListener implements IAnnotationTransformer {
 
	public void transform(ITestAnnotation annotation, Class testClass,Constructor testConstructor, Method testMethod) {       
       
		configureVariable();
				
		if (testMethod.getName().equals("Charlie")) {
        	 System.out.println("set priority for " + testMethod.getName()); 
        	 System.out.println("config.testMethodRun:" + config.testMethodRun);
        	if(config.testMethodRun==true)
         	{
         		annotation.setPriority(2);
         		//annotation.setAlwaysRun(true);
         	}
             
        } else if (testMethod.getName().equals("assessmentTest")) {
        	System.out.println("config.testMethodRun:" + config.testMethodRun);
        	if(config.testMethodRun==true)
         	{
        		annotation.setPriority(3);
        		annotation.setEnabled(false);
        		
         	}
        	
        }
    	
    	
    }
	
	
	public void configureVariable()
	{
		config.testMethodRun=true;
	}
}
