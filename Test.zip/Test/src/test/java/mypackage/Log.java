package mypackage;

public class Log {

}
