package mypackage;

import java.io.File;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SimpleMail {
	
	

		 public static void main(String[] args){
			 
			 try {
			   
				String ccEmailList="gajanan+ccemail@shortlist.net";
				String emailSubjectLine="Candidate Portal - Sanity Test | Automation Report";
				String reportFilePath="C:\\Shortlist\\workspace\\SeleniumAssigments\\AutomationTestReport.html";
				String totalTestCount="5";
				String totalTestPassed="2";
				String totalTestFailed="2";
				String totalTestSkipped="1";
				String environment="QA";
				String browser="Chrome";
				String browserVersion="78";
				String exectionOn="Gajanan";
				String startTime="2020/01/29 02:30:40";
				String endTime="2020/01/29 02:30:40";
			 
			 
			 
		        System.out.println("Sending mail...");
		        Properties prop = new Properties();
				prop.put("mail.smtp.host", "smtp.gmail.com");
		        prop.put("mail.smtp.port", "587");
		        prop.put("mail.smtp.auth", "true");
		        prop.put("mail.smtp.starttls.enable", "true");
		        
		        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
		                    protected PasswordAuthentication getPasswordAuthentication() {
		                        return new PasswordAuthentication("gajanan@shortlist.net", "Short@2019");
		                    }
		                });
		        



			String htmlContent = "<div style=\"width:550px\"> <hr> </div>"+
			""+
			"<h3 style=\"padding-bottom: 10px;font-size: 1.42857143em;font-style: inherit;font-weight: 500;letter-spacing: -0.008em;line-height: 1.2;margin-top: 28px;padding-left:150px\">Automation Test Execution Status</h3>"+
			"<div style=\"width:550px\"> <hr> </div>"+
			"<br>"+
			"<div style=\"display: inline-block; float: left; position: relative;top: 11px; font-size: 14px;font-weight: bold;\">TOTAL TESTS:� "+totalTestCount+"</div>"+
			"<br><br>"+
			"<div  style=\"display: inline-block;\">"+
			"<span style=\"color: rgb(149, 193, 96);font-size: 50px;\"  color=\"#95C160\">"+totalTestPassed+"</span>"+
			"<span style=\"padding-right: 20px;font-weight: bold;\">PASSED</span>"+
			"</div>"+
			"<div style=\"display: inline-block;\">"+
			"<span style=\"color: rgb(212, 93, 82);font-size: 50px;\"  color=\"#D45D52\">"+totalTestFailed+"</span>"+
			"<span style=\"padding-right: 20px;font-weight: bold;\">FAILED</span>"+
			"</div>"+
			"<div style=\"display: inline-block;\">"+
			"<span style=\" color: rgb(241, 224, 105);font-size: 50px;\" color=\"#F1E069\">"+totalTestSkipped+"</span>"+
			"<span style=\"padding-right:20px;font-weight: bold;\">Skipped</span>"+
			"</div>"+
			"<br><br>"+
			"<table  style=\"font-size:18px;font-weight:100;letter-spacing: -0.008em;line-height: 1.5;padding-left:10px;margin-top:50px\" >"+
			" <caption>---------------�Test Details �-----------------</caption>"+
			"  <tr>"+
			"    <td style=\"width:130px\">Test Environment</td>"+
			"    <td>:� "+environment+"</td>"+
			"  </tr>"+
			"  <tr>"+
			"    <td>Test Type        </td>"+
			"    <td>:� Sanity Testing</td>"+
			"  </tr>"+
			"  <tr>"+
			"    <td>Module Name      </td>"+
			"    <td>:� Candidate Portal</td>"+
			"  </tr>"+
			"  <tr>"+
			"    <td>Browser          </td>"+
			"    <td>:� "+browser+" v."+browserVersion+"</td>"+
			"  </tr>"+
			"   <tr>"+
			"    <td>Platform         </td>"+
			"    <td>:� Win86</td>"+
			"  </tr>"+
			"   <tr>"+
			"    <td>Execution</td>"+
			"    <td>:� "+exectionOn+"</td>"+
			"  </tr>"+
			"   <tr>"+
			"    <td>Start time</td>"+
			"    <td>:� "+startTime+"</td>"+
			"  </tr>"+
			"   <tr>"+
			"    <td>End Time         </td>"+
			"    <td>:� "+endTime+"</td>"+
			"  </tr>"+
			"</table>"+
			"<p style=\"color:blue;background-color:yellow;font-weight:bold;padding:10px; width:600px;margin-top:100px;margin-bottom:50px\">"+
			"Please download attached test report and click on the downloaded file to view </p>";
	
	

		        MimeMessage message = new MimeMessage(session);
		        message.setSubject(emailSubjectLine);
		        message.setFrom(new InternetAddress("gajanan@shortlist.net"));
		        message.addRecipient(Message.RecipientType.TO,
		             new InternetAddress("gajanan@shortlist.net"));
		        if(!ccEmailList.isBlank()) {
		        	message.addRecipients(Message.RecipientType.CC,InternetAddress.parse(ccEmailList));
		        }
		       
		        
		        Multipart multipart = new MimeMultipart();
		        
		        MimeBodyPart textPart = new MimeBodyPart();
		        textPart.setContent(htmlContent, "text/html");
		        multipart.addBodyPart(textPart);
		        
		        MimeBodyPart attachementPart = new MimeBodyPart();
		        attachementPart.attachFile(new File(reportFilePath));
		        multipart.addBodyPart(attachementPart);
		        
		        message.setContent(multipart);
		        

	            Transport.send(message);

	            System.out.println("Done");
	            
			 }catch (Exception e) {
				System.out.print(e.getMessage());
			}
	            
		        }
			 
		
	

}
