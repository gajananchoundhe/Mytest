package mypackage;

public class PieChartExample {

	public static void main( String[ ] args ) throws Exception {
		String sysUserName = System.getProperty("user.name");
		System.out.println(sysUserName);
	
	
	}	
}
