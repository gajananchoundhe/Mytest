package mypackage;

public class TestSample {

	int number;

	public int getNum() {
		return number;
	}

	@Override
	public String toString() {
		return "TestSample [num=" + number + "]";
	}

	public TestSample(int num) {
		super();
		this.number = num;
	}

	public void setNum(int num) {
		this.number = num;
	}

	/**
	 * This is test method for debugging purpose
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) {

		for (int i = 5; i <= 5; i++) {
			int sum = 0;
			int q = 5;
			try {
				sum = getTotal(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e.getCause());
			}
			System.out.println(sum);
			if (i >= 11) {
				System.out.println("Exit");
			}

		}
	}

	/**
	 * This method return sum of two number
	 * 
	 * @param n integer number
	 * @return Integer value of sum of two number
	 * @throws Division by zero
	 */
	public static int getTotal(int n) throws Exception {

		int sum = 1 / 0;
		return sum;

	}

}
