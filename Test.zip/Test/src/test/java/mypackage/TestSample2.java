package mypackage;

public class TestSample2 {

	public static void main(String[] args) {

		String test=System.getProperty("testA");
		if(test!=null)
		{
			System.out.println("Not null");
			
		}else {
			System.out.println("Null");
		}
	}

}
