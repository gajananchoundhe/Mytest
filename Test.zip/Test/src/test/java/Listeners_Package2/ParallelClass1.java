package Listeners_Package2;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import static org.testng.Assert.assertEquals;

import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

public class ParallelClass1 {
	
 
	
  @Test(priority=1)
  public void login() {
	  
	  Reporter.testStart("Login to candidate portal");
	  Reporter.addPassTest("Username entered");
	  Reporter.addPassTest("Password entered");
	  Reporter.addPassTest("Clicked on loggin button");
	  Reporter.addPassTest("Logged successfully");
	  
  }
  
  @Test(priority=2)
  public void logout() {
	  
	  Reporter.testStart("Logout to candidate portal");
	  Reporter.addPassTest("Navigate to logout menu");
	  assertEquals("","Log out successfully");
	  Reporter.addFailTest("Log out not successfully");
  }
  
  @Test(priority=3)
  public void searchCandidate() {
	  
	  Reporter.testStart("Search candidate");
	  Reporter.addPassTest("Navigate to search candidate page");
	  Reporter.addPassTest("Candidate search successfully");
  }
  
  @Test(priority=4)
  public void uploadCandidate() {
	  
	  Reporter.testStart("Upload candidate");
	  Reporter.addPassTest("Navigate to candidate upload page");
	  Reporter.addPassTest("Candidate uploaded successfully");
  }
  
  
  
  

  @AfterMethod(enabled=false)
  public void afterMethod() {
	  
	  //Reporter.testEnd();
  }
  
  
  @BeforeSuite
  public void beforeSuite() {
	  
	  Reporter.startReport();
  }

  
  @AfterSuite
  public void afterSuite() {
	  
	  Reporter.endReport();
  }

  

}
