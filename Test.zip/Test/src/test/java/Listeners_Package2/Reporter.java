package Listeners_Package2;

import java.io.File;

import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Reporter {

	static ExtentTest test;
	static ExtentReports report;
	
	
	public static void testStart(String testName)
	{
		test = report.startTest(testName);
	}
	
	
	public static void addPassTest(String stepDescription)
	{
		test.log(LogStatus.PASS, stepDescription);
	}
	
	public static void addFailTest(String stepDescription)
	{
		test.log(LogStatus.FAIL, stepDescription);
	}
	
	public static void addInfo(String info)
	{
		test.log(LogStatus.INFO, info);
	}
	
	
	
	
	public static void testEnd()
	{
		report.endTest(test);		
	}
	
	
	public static void startReport()
	{
		String extConfig="C:\\Shortlist\\workspace\\Test\\src\\main\\resources\\configFile\\extent-config.xml";
		report = new ExtentReports(System.getProperty("user.dir")+"\\AutomationTestResults.html",true);
		report.loadConfig(new File(extConfig));
		report.addSystemInfo("Selenium Version", "2.46");
		report.addSystemInfo("Environment", "Prod");
	}
	
	public static void endReport()
	{
		report.flush();
	}
	
	
	
}
