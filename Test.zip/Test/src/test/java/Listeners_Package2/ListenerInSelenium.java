package Listeners_Package2;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;
import com.relevantcodes.extentreports.ReporterType;


public class ListenerInSelenium extends TestBase implements ITestListener {
	
	
	public void onFinish(ITestContext arg0) {
		Reporter.log("Test is finished:" + arg0.getName());

	}

	public void onStart(ITestContext arg0) {
		Reporter.log("Test is started:" + arg0.getName());

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestFailure(ITestResult arg0) {

					
		if (!arg0.isSuccess()) {
									
			Listeners_Package2.Reporter.addFailTest(arg0.getThrowable().getMessage());
			Listeners_Package2.Reporter.testEnd();
		}

	}

	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestStart(ITestResult arg0) {
		Reporter.log(ITestResult.class.getSimpleName() + " Test started");

	}

	public void onTestSuccess(ITestResult arg0) {
		if (arg0.isSuccess()) {
			
			Listeners_Package2.Reporter.testEnd();
			
		}


	}

}
