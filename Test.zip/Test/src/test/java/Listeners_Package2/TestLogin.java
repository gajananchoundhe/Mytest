package Listeners_Package2;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class TestLogin extends TestBase{
	
	static ExtentTest test;
	static ExtentReports report;
	
	
	@Test(enabled=true)
	public void testEventListener() throws InterruptedException{
	driver.get("http://automationpractice.com/index.php");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	WebDriverWait wait = new WebDriverWait(driver, 200);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a"))));
	driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();
	

	driver.findElement(By.xpath("//*[@id='email']")).sendKeys("testCode");
	driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("testpass");
	driver.findElement(By.xpath("//*[@id='SubmitLogin122']")).click();
	}
	
	@Test(enabled=false)
	public void openWebsite() {
		
		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
		test.log(LogStatus.PASS, "Navigated to the specified URL");
		test.log(LogStatus.FAIL, "Test Failed");

		report.endTest(test);
		report.flush();

	}
	

	
	
	
}