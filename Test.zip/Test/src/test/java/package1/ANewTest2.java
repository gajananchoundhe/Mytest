package package1;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;

public class ANewTest2 {
	
  @Test
  public void test2() {
	  System.out.println("This is test last");
  }
  

}
