package package1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.bson.Document;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;



public class Database__test {

	static Connection connection=null;
	static String QA_SHORTLIST_DB_URL="jdbc:mysql://stagingsep.c98kszjbfxlr.ap-southeast-1.rds.amazonaws.com:3306/?user=gajanan&password=Admin@123";
	static String QA_Chatbot_DB_URL="jdbc:mysql://stagingchatbot.c98kszjbfxlr.ap-southeast-1.rds.amazonaws.com:3306/?user=gajanan&password=Admin@123";
	
	public static void main(String[] args) {
		
		try {
			
		      
			//mangoDBQA();
			
			getJobAssessementList();
			 
			
					
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
	}
	
	
	public static void mangoDBQA() {
		
		
		MongoClientURI mongoClientURI = new MongoClientURI("mongodb://gajanan:8Yr4qxkMAArjS6Sv@staging-shard-00-00-0kb4w.mongodb.net:27017,staging-shard-00-01-0kb4w.mongodb.net:27017,staging-shard-00-02-0kb4w.mongodb.net:27017/admin?ssl=true&replicaSet=staging-shard-0&authSource=admin");
		MongoClient mongoClient = new MongoClient(mongoClientURI);
		MongoDatabase database = mongoClient.getDatabase("candidate");
		
		System.out.println("Collection created successfully"); 
	      for (String name : database.listCollectionNames()) { 
	         System.out.println(name); 
	      } 
	      FindIterable<Document> collection = database.getCollection("userassessment").find(Filters.eq("userId", "5e203e5e5908010001a012d2"));
	      Document document=collection.first();
	      System.out.println("assessmentStatus: "+ document.getString("assessmentStatus")); 
	      System.out.println("candidateId: "+ document.getInteger("candidateId")); 
	      System.out.println("completedQuestions: "+ document.getInteger("completedQuestions")); 
		
	}

	
	
	
	
	
	
	public static void getCandidateId() {

		String email = "gajanan.choundhe+202001151@gmail.com";
		
		String getCandidateIdQuery = "SELECT  userId  FROM shortlist_prod.candidateprofile a where CAST(aes_decrypt(unhex(a.email),'careercalling') as char)='"
				+ email + "';";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getCandidateIdQuery);
			while (rs.next()) {
				System.out.println("CandidateID: " + rs.getInt("userId"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}

	}

	public static void getJobDetails() {
		
		int jobId = 1297;
		
		String getJobDetailQuery = "SELECT * FROM shortlist_prod.jobopening where id=" + jobId + ";";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getJobDetailQuery);
			while (rs.next()) {
				System.out.println("jobId: " + rs.getInt("id")); // jobId
				System.out.println("flowId: " + rs.getString("flowId"));
				System.out.println("jobTitle: " + rs.getString("jobTitle"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}

	}

	public static void getCandidateJobAppliedStatus() {
		
		int jobId = 1124;
		int candidateId = 374082;
		
		String getCandidateJobStatusQuery = "SELECT jobStatus FROM shortlist_prod.jobapplied where jobId=" + jobId
				+ " and candidateId=" + candidateId + ";";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getCandidateJobStatusQuery);
			while (rs.next()) {
				System.out.println("jobStatus: " + rs.getString("jobStatus"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}

	}

	public static ArrayList<String> getJobAssessementList() {
		
		int jobId = 1297;
		
		ArrayList<String> list=new ArrayList<String>();
		
		String getAssessementListQuery = "SELECT * FROM shortlist_prod.job_assessment_rel where jobId=" + jobId + ";";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getAssessementListQuery);

			while (rs.next()) {
				System.out.println("Assessment Name: " + rs.getString("assessmentName"));
				list.add(rs.getString("assessmentName"));
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}
		
		return list;

	}
	
	
	public static void getCandidateChatbotResponseDetails() {
		
		int jobId = 1297;
		int flowId=1057;
		int candidateId=22317;
		String email="gajanan.choundhe+202001151@gmail.com";
		
		String getCandidateReponseQuery="SELECT questionText, CAST(aes_decrypt(unhex(a.response),'careercalling') as char) as responses  FROM chatbot.candidateresponse as a where flowId="+flowId+" and candidateId="+
		"(SELECT candidateId FROM chatbot.candidate a where  CAST(aes_decrypt(unhex(a.email),'careercalling') as char)='"+email+"');";
		
		try {
			/*ResultSet rs = getQueryResult(QA_Chatbot_DB_URL, getCandidateIdFromChatbotDB);
			if (rs.next() == true) {
				System.out.println("candidateId: " + rs.getString("candidateId"));
			} else {
				System.out.println("No result found");
			}*/
			
			ResultSet result = getQueryResult(QA_Chatbot_DB_URL, getCandidateReponseQuery);
			if (result.next()== true) {
				result.previous();
			while (result.next()) {
				
				System.out.println("Question: "+result.getString("questionText"));
				System.out.println("Response: "+result.getString("responses"));
			}
			}else {
				System.out.println("No Response found");
			}
			

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}

	}
	
	
	public static void isPsychometricOrderExist() {
		
		String email="swapnil+09092019111@shortlist.net";
		
		String getPsychometricOrderQuery = "SELECT * FROM psychometric.psyresponses where 01A!=0 and userid=(SELECT id FROM psychometric.user where emailaddress='"+email+"');";
		try {
			ResultSet rs = getQueryResult(QA_SHORTLIST_DB_URL, getPsychometricOrderQuery);

			if (rs.next() == true)  {
				System.out.println("Psychometric order is exist");
			}else {
				System.out.println("Psychometric order is not exist");
			}

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			closeConnection();
		}
	}
	
	
	
	

	public static ResultSet getQueryResult(String dbURL, String query) {

		ResultSet result = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(dbURL);
			Statement stmt = connection.createStatement();
			result = stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;

	}

	public static void closeConnection() {
		try {
			if (connection != null)
				connection.close();
			System.out.println("Connection closed !!");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
	
	

}
