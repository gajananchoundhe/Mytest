package package1;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;


public class ListTest {

	public static void main(String[] args) throws IOException {

		//HashMap<String, String> capitalCities = new HashMap<String, String>();

	  //  capitalCities.put("Thanks, what city do you currently live in?", "London");
	   // capitalCities.put("From which institution did/will you receive this degree or credential?", "Berlin");
		//awsS3();
		
		//https://devcenter.heroku.com/articles/using-amazon-s3-for-file-uploads-with-java-and-play-2
		//https://www.devglan.com/spring-mvc/aws-s3-java
		
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		System.out.println(dateFormat.format(date)); 
		String folderName="gajanan_"+dateFormat.format(date);
		
		BasicAWSCredentials creds = new BasicAWSCredentials("AKIAIK42FPGYVY4EK6OA", "GfJCFifC9C+IEqindEhfEzNzdJPKbkKJKkVcv2W+"); 
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).withCredentials(new AWSStaticCredentialsProvider(creds)).build();
		
		
		//createFolder("candidate-automation-report", folderName, s3Client);
		
		String bucketName = "my-first-s3-bucket-" + UUID.randomUUID();
		System.out.println(bucketName);
		
		awsS3();
		
		
	}
	
	
	public static void createFolder(String bucketName, String folderName, AmazonS3 client) {
		// create meta-data for your folder and set content-length to 0
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(0);

		// create empty content
		InputStream emptyContent = new ByteArrayInputStream(new byte[0]);

		// create a PutObjectRequest passing the folder name suffixed by /
		PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
					folderName, emptyContent, metadata);

		// send request to S3 to create folder
		client.putObject(putObjectRequest);
	}
	
	
	public static void awsS3() {
		
		AWSCredentials credentials = new BasicAWSCredentials("AKIAIK42FPGYVY4EK6OA", "GfJCFifC9C+IEqindEhfEzNzdJPKbkKJKkVcv2W+");
		@SuppressWarnings("deprecation")
		AmazonS3 s3client = new AmazonS3Client(credentials);
		for (Bucket bucket : s3client.listBuckets()) {
			System.out.println(" - " + bucket.getName());
		}
	
		System.out.println("filelink: " + s3client.getUrl("candidate-automation-report", "AutomationTestResults.html"));
		
		
		
				String fileName = "C:\\Users\\npuja\\Pictures\\Screenshots\\Screenshot1.png";
				s3client.putObject(new PutObjectRequest("candidate-automation-report", "gajanan_20200121001817/Screenshot2.png",new File(fileName))
						.withCannedAcl(CannedAccessControlList.PublicRead));
				
				
				System.out.println("filelink: " + s3client.getUrl("candidate-automation-report", "gajanan_20200121001817/Screenshot2.png"));
	}
	
	
	
	
	

	public static char getIndustiesStartWithLetter() {

		char[] industryCharList = { 'A', 'B', 'C', 'E', 'F', 'H', 'I', 'M', 'O', 'P', 'R', 'S', 'T' };
		char industryChar = industryCharList[getRandomNumber(industryCharList.length)];
		return industryChar;

	}

	public static int getRandomNumberFromRange(int min, int max) {

		
		Random r = new Random();
		int result = r.nextInt(max - min) + min;
		System.out.println("Generated random number : " + result);
		return result;
	}

	public static int getRandomNumber(int maxNumber) {

		Random random = new Random();
		int randomNum = random.nextInt(maxNumber);
		if (maxNumber != 0 && randomNum == 0) {
			randomNum = 1;
			System.out.println("Default generated random number : " + randomNum);
		} else {
			System.out.println("Generated random number : " + randomNum);
		}

		return randomNum;
	}

}
