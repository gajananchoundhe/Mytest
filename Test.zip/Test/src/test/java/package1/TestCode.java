package package1;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class TestCode {

	public static void main(String[] args) {

		System.out.println(System.getProperty("user.dir"));
		
		String filePath=System.getProperty("user.dir")+"\\ConfigData\\config.properties";
		System.out.println("File Path :"+ filePath);
		
		try{
			
			InputStream input = new FileInputStream(filePath);
		    
            Properties prop = new Properties();
            prop.load(input);
            System.out.println(prop.getProperty("qa.url.login"));
            

        } catch (Exception ex) {
            System.out.println("Exception: "+ ex.getMessage());
        }
			
		
	}
	
	
	
	
	
	
	

}
