package package1;

import java.lang.reflect.Method;

import org.apache.commons.exec.launcher.Java13CommandLauncher;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest {

	@Test(priority = 1)
	public void opsLoginTest() {
		System.out.println("This is test First");
	}

	@Test(priority = 2)
	public void ALoginTest() {

		System.out.println("This is test First -2");

	}

	@BeforeTest
	public void beforeTest() {
		System.out.println("Beforee Test");
	}
	
	@BeforeMethod
	public void beforeMethod(Method method) {
		System.out.println("Method name: " + method.getName());
	}

}
